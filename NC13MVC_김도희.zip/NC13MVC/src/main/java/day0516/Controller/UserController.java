package day0516.Controller;

import day0516.Model.UserDTO;

import java.util.ArrayList;

public class UserController {
    private ArrayList<UserDTO> list; // 유사 DB 역할을 할 ArrayList 필드
    private int nextId; // 다음 입력될 회원 번호 저장할 int 필드

    public UserController() {
        list = new ArrayList<>();
        nextId = 1;
    }

    public void insert(UserDTO userDTO) {
        userDTO.setId(nextId++);
        list.add(userDTO);
    }

    // 가입자 이름이 중복되는지 확인하기 위한 메소드
    public boolean validateUsername(String username) {
        for (UserDTO u : list) {
            if (u.getUsername().equalsIgnoreCase(username)) { // 대소문자 상관없이 가입자 이름이 동일하다면, 악용되기를 막기 위함
                return false;
            }
        }

        return true;
    }

    // id가 겹치는 값을 찾아냄
    public UserDTO selectOne(int id) {
        UserDTO temp = new UserDTO();
        temp.setId(id);
        if (list.contains(temp)) {
            return list.get(list.indexOf(temp));
        }
        return null;
    }

    public void update(UserDTO userDTO) {
        list.set(list.indexOf(userDTO), userDTO);
    }

    public void delete(int id) {
        UserDTO temp = new UserDTO();
        temp.setId(id);

        list.remove(temp);
    }

    public UserDTO auth(String username, String password) { // 아이디와 비밀번호가 회원가입된 것과 같은지 체크
        for (UserDTO u : list) {
            if (username.equalsIgnoreCase(u.getUsername())) { // 아이디는 대소문자 체크
                if (password.equals(u.getPassword())) { // 패스워드는 대소문자 상관 x
                    return u;
                }
            }
        }

        return null; // 정보와 일치하지 않는 아이디 혹은 비번이라면 null 반환
    }

    // id에 맞는 nickname 가져오는 메소드
    public String selectNicknameById(int id) {
        UserDTO userDTO = new UserDTO();
        userDTO.setId(id);

        return list.get(list.indexOf(userDTO)).getNickname(); //list에서 파라미터 새로운 객체 UserDTO의 id를 가져오고 그 아이디와 세트로 저장된 닉네임 가져오기
    }
}
