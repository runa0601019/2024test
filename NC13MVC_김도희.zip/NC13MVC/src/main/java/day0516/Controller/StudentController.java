package day0516.Controller;
// 컨트롤러 Controller

import day0516.Model.StudentDTO;

import java.lang.reflect.Array;
import java.util.ArrayList;

public class StudentController {
    private ArrayList<StudentDTO> list; // 유사 DB 역할을 할 ArrayList 필드
    private int nextId; // 다음 입력될 학생의 번호를 저장할 int 필드

    public StudentController() {
        list = new ArrayList<>();
        nextId = 1;
    }

    // 1. 사용자로부터 StudentDTO 객체 전달받아 list에 추가하는 insert()
    public void insert(StudentDTO s) {
        s.setId(nextId++);
        list.add(s);
    }

    // 2. 현재 리스트 전체를 보내주는 selectAll()
    public ArrayList<StudentDTO> selectAll() {
        return list;
    }

    // 3. 특정 id 값을 가진 StudentDTO 객체를 리턴하는 selectOne() -> 단, 해당 id값이 존재하지 않으면 null return
    public StudentDTO selectOne(int id) {
        StudentDTO temp = new StudentDTO();
        temp.setId(id);

        if (list.contains(temp)) {
            return list.get(list.indexOf(temp));
        }

        return null;
    }

    // 4. 사용자가 보낸 StudentDTO 객체로 리스트의 특정 요소를 수정하는 update()
    public void update(StudentDTO s) {
        int index = list.indexOf(s);
        list.set(index, s);
    }

    // 5. 특정 id 값을 가진 객체를 list에서 삭제하는 delete()
    public void delete(int id) {
        StudentDTO temp = new StudentDTO();
        temp.setId(id);
        list.remove(temp);
    }

    // StudentMain에서 쓰이기 위해 만든 메소드 6,7
    // 6. 파라미터로 들어온 학생 객체의 총점을 계산하는 메소드
    public int calculateSum(StudentDTO s) {
        return s.getKorean() + s.getEnglish() + s.getMath();
    }

    // 7. 파라미터로 들어온 학생 객체의 평균을 계산하는 메소드
    public double calculateAverage(StudentDTO s) {
        return (double) calculateSum(s) / 3;
    }
}
