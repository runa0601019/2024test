package day0516.Controller;

import day0516.Model.BoardDTO;
import day0516.Model.ReplyDTO;
import lombok.Setter;

import java.util.ArrayList;

// 댓글 달기, 댓글은 각 게시글마다 생겨야 하므로 한 게시글 작성 시 바로 만들어줄 수 있게 해야함
public class ReplyController {
    private ArrayList<ReplyDTO> list;
    private int nextId;

    public ReplyController() {
        list = new ArrayList<>();
        nextId = 1;
    }

    public void insert(ReplyDTO replyDTO) {
        replyDTO.setId(nextId++);
        list.add(replyDTO);
    }

    public ReplyDTO selectOne(int id) {
        ReplyDTO temp = new ReplyDTO();
        temp.setId(id);

        if (list.contains(temp)) {
            return list.get(list.indexOf(temp));
        }
        return null;
    }

    public ArrayList<ReplyDTO> selectAll() {
        return list;
    }

    public void update(ReplyDTO replyDTO) {
        list.set(list.indexOf(replyDTO), replyDTO);
    }

    public void delete(int id) {
        ReplyDTO replyDTO = new ReplyDTO();
        replyDTO.setId(id);
        list.remove(replyDTO);
    }

    public boolean validateInput(ArrayList<ReplyDTO> list, int input) {
        if (input == 0) return true;

        ReplyDTO replyDTO = new ReplyDTO();
        replyDTO.setId(input);
        return list.contains(replyDTO); // input을 아이디로 가지고 있는 boardDTO가 있는지 확인해서 그 값을 리턴
    }
}
