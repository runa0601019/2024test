package day0516.Model;
// 모델

// @Data 하려면 노션 NC13MVC 뉴프로젝트 생성 들어가서 확인하기

import lombok.Data;
/* lombok은 게터/세터, toString() 등 모델 클래스들에게 필요한 기본 메소드를 자동으로 생성해주는 외부 라이브러리
   필요에 따라서는 우리가 직접 @Getter @Setter 등 필요한 것을 골라서 쓸 수 있지만 @Data라고 적어주면 모든 기능 다 활성화 됨
   단, equals 제외이므로 만들어줘야함

   따라서, 데이터를 자바 객체 형태로 바꾸는 것만 하면 되기 때문에 @Data 필드 equals만 적어주면 끝*/

@Data
public class StudentDTO { // 학생의 정보를 객체화시키기 때문에 StudentDTO, 일종의 데이터를 객체화 시켜주는 것
    private int id;
    private String name;
    private int korean;
    private int english;
    private int math;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;

        if (o instanceof StudentDTO) {
            StudentDTO s = (StudentDTO) o;
            return id == s.id;
        }
        return false;
    }


}