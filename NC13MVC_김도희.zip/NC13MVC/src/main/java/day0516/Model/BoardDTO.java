package day0516.Model;

import lombok.Data;

@Data
public class BoardDTO { // 게시글 기능 구현하기 위한 DTO
    private int id;
    private String title;
    private String content;
    private int writerId; // 작성자 아이디 가져와야함

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }

        if (o instanceof BoardDTO) {
            BoardDTO b = (BoardDTO) o;
            return id == b.id;
        }
        return false;
    }
}
