package day0516.Model;

import lombok.Data;

@Data
public class ReplyDTO { // 댓글 기능 구현하기 위한 DTO
    private int id; // 댓글의 id
    private String content;
    private int writerId; // 댓글 작성한 작성자 아이디
    private int boardId; // 댓글을 작성할 게시글 아이디

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o instanceof ReplyDTO) {
            ReplyDTO r = (ReplyDTO) o;
            return id == r.id;
        }
        return false;
    }
}
