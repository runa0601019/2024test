package day0516.Model;


import lombok.Data;

@Data // getter setter 알아서 만들어줌, equals는 안 만들어주기 때문에 직접 만들 것
public class UserDTO {
    private int id;
    private String username;
    private String password;
    private String nickname;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;

        if (o instanceof UserDTO) {
            UserDTO u = (UserDTO) o;
            return id == u.id;
        }

        return false;
    }
}
