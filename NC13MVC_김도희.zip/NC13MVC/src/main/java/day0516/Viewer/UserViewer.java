package day0516.Viewer;

import day0516.Controller.UserController;
import day0516.Model.UserDTO;
import miniProject.ScannerUtil;
import lombok.Getter;
import lombok.Setter;

import java.util.Scanner;

public class UserViewer {
    @Setter
    private UserController userController;
    @Setter
    private Scanner sc;
    @Getter
    private UserDTO logIn; // 로그인 한 번 하고 나면 유지되도록 하기위함
    @Setter
    private BoardViewer boardViewer; // 게시판 입력을 위해서 가져와함
    @Setter
    private ReplyViewer replyViewer;

    public void showIndex() {
        while (true) {
            int choice = ScannerUtil.printInt(sc, "1. 로그인 2. 회원가입 3. 프로그램 종료>", 1, 3);
            if (choice == 1) {
                auth(); // 회원가입된 아이디와 비번인지 체크하는 메소드
                if (logIn != null) { // 로그인 성공했다는 것
                    boardViewer.setLogIn(logIn); // 로그인 성공했다는 것을 boardViewer에게도 알려줘야함
                    showMain(); // 회원메뉴실행
                }
            } else if (choice == 2) { // 회원가입
                register(); // 0516 숙제 만들어오기
            } else if (choice == 3) {
                System.out.println("이용해주셔서 감사합니다.");
                break;
            }
        }
    }

    // 회원가입된 아이디와 비밀번호가 맞는지 체크
    private void auth() {
        String username = ScannerUtil.printString(sc, "아이디를 입력>");
        String password = ScannerUtil.printString(sc, "비밀번호 입력>");

        logIn = userController.auth(username, password);

        if (logIn == null) {
            System.out.println("잘못 입력. 로그인 정보 재확인 요망");
        } else {
            System.out.println("로그인 성공");
        }
    }

    // 숙제. 선생님코드
    private void register() {
        String username = ScannerUtil.printString(sc, "아이디: ");
        if (userController.validateUsername(username)) {
            // 중복되지 않은 아이디이므로 나머지 정보를 입력받음
            String password = ScannerUtil.printString(sc, "비밀번호: ");
            String nickname = ScannerUtil.printString(sc, "닉네임: ");

            UserDTO temp = new UserDTO();
            temp.setUsername(username);
            temp.setPassword(password);
            temp.setNickname(nickname);
            userController.insert(temp);
        } else {
            System.out.println("중복된 아이디 사용불가");
        }
    }

    // 회원메뉴실행
    private void showMain() {
        while (logIn != null) {
            int choice = ScannerUtil.printInt(sc, "1. 게시판으로 2. 회원 정보 수정 3. 로그아웃>", 1, 3);
            if (choice == 1) {
                boardViewer.showMenu(); // BoardViewer의 showMenu()는 여기서 실행이 되어야 logIn 정보가 전달 가능
            } else if (choice == 2) {
                printInfo();
            } else if (choice == 3) {
                logIn = null; // logIn 초기화, while의 조건문이 logIn!=null 이기 때문에 break 적지 않아도 자동 종료
                System.out.println("로그아웃합니다.");
            }
        }
    }

    // 2. 회원 정보 수정 메소드
    private void printInfo() {
        // 회원 정보 출력
        System.out.println("=========================");
        System.out.println(logIn.getNickname() + " 회원님의 정보");
        System.out.println("-------------------------");
        System.out.println("회원 번호: " + logIn.getId());
        System.out.println("회원 아이디: " + logIn.getUsername());
        System.out.println("회원 닉네임: " + logIn.getNickname());
        System.out.println("=========================");

        int choice = ScannerUtil.printInt(sc, "1. 회원 정보 수정 2. 회원 탈퇴 3. 뒤로 가기>", 1, 3);
        if (choice == 1) {
            update();
        } else if (choice == 2) {
            delete();
        } else if (choice == 3) { // 뒤로가기 따로 실행하지않아도 어차피 실행종료되어서 돌아오게됨
            System.out.println("회원 메뉴로 이동합니다.");
        }
    }

    private void update() {
        String newNickname = ScannerUtil.printString(sc, "새로운 닉네임>");
        String newPassword = ScannerUtil.printString(sc, "새로운 비밀번호>");
        String oldPassword = ScannerUtil.printString(sc, "기존 비밀번호>");
        if (oldPassword.equals(logIn.getPassword())) {
            logIn.setNickname(newNickname);
            logIn.setPassword(newPassword);

            userController.update(logIn);
        } else {
            System.out.println("비밀번호를 다시 입력하세요");
            oldPassword = ScannerUtil.printString(sc, "기존 비밀번호>");
        }
    }

    private void delete() {
        String answer = ScannerUtil.printString(sc, "정말로 탈퇴하시겠습니까? Y/N>");
        if (answer.equalsIgnoreCase("Y")) {
            userController.delete(logIn.getId());
            System.out.println("삭제하였습니다.");
        }
    }
//    // 회원가입 메소드
//    private void register() {
//        String answer = ScannerUtil.printString(sc, "회원가입을 하시겠습니까? Y/N>");
//        if (answer.equalsIgnoreCase("Y")) {
//            UserDTO u = new UserDTO();
//            String username = ScannerUtil.printString(sc, "앞으로 쓸 아이디>");
//            String password = ScannerUtil.printString(sc, "앞으로 쓸 비밀번호>");
//
//            // 아이디 중복이라면 재입력
//            while (!userController.validateUsername(username)) {
//                System.out.println("중복된 아이디, 재입력 요망");
//                username = ScannerUtil.printString(sc, "앞으로 쓸 아이디>");
//            }
//            // 비밀번호 중복이라면 재입력
//            while (!userController.validateUsername(password)) {
//                System.out.println("중복된 비밀번호, 재입력 요망");
//                password = ScannerUtil.printString(sc, "앞으로 쓸 비밀번호>");
//            }
//
//            // UserDTO의 username과 password에 넣어줌
//            u.setUsername(username);
//            u.setPassword(password);
//            // username과 password를 넣은 UserDTO u를 ArrayList에 넣어줌
//            userController.insert(u);
//
//            System.out.println("회원가입 성공");
//        } else {
//            System.out.println("메인화면으로 돌아갑니다.");
//            showIndex();
//        }
//    }
}
