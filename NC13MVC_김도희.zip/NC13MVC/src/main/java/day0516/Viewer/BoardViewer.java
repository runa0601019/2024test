package day0516.Viewer;

import day0516.Controller.BoardController;
import day0516.Controller.ReplyController;
import day0516.Controller.UserController;
import day0516.Model.BoardDTO;
import day0516.Model.UserDTO;
import miniProject.ScannerUtil;
import lombok.Setter;

import java.util.ArrayList;
import java.util.Scanner;

public class BoardViewer {
    @Setter
    private BoardController boardController;
    @Setter
    private UserController userController; // 회원정보 저장되어있는 userController 가져옴
    @Setter
    private ReplyViewer replyViewer; // 댓글 입력을 위해서는 가져와야함
    @Setter
    private ReplyController replyController;
    @Setter
    private Scanner sc;
    @Setter
    private UserDTO logIn; // writerId == 로그인정보에 있는 닉네임을 가진 사람이 글을 쓸 것이기 때문에 logIn 정보를 받아온다

    public void showMenu() {
        while (true) {
            int choice = ScannerUtil.printInt(sc, "1. 글 작성하기 2. 글 목록보기 3. 뒤로 가기>", 1, 3);
            if (choice == 1) {
                insert();
            } else if (choice == 2) {
                printList();
            } else if (choice == 3) {
                System.out.println("회원 메뉴로 돌아갑니다.");
                break;
            }
        }
    }

    private void insert() {
        BoardDTO boardDTO = new BoardDTO();

        // WriterId는 로그인한 사람의 닉네임을 가져와야함, 그렇기 때문에 userViewer에서 logIn 정보를 전달받아야 실행 가능
        boardDTO.setWriterId(logIn.getId());

        boardDTO.setTitle(ScannerUtil.printString(sc, "글 제목>"));
        boardDTO.setContent(ScannerUtil.printString(sc, "글 내용>"));

        boardController.insert(boardDTO);
    }

    private void printList() {
        ArrayList<BoardDTO> list = boardController.selectAll();
        if (list.isEmpty()) System.out.println("아직 작성된 글이 없습니다.");
        for (BoardDTO b : list) {
            // writerId인 닉네임을 가져오려면 회원정보를 가지고 있는 userController에 있는 ArrayList<UserDTO> list에 접근해야함, 그렇기 때문에 상단에 userController도 추가해줘야함
//            System.out.printf("%d. %s - %s\n", b.getId(), b.getTitle(), b.getWriterId()); // 따라서 단순히 b.getWriterId()가 아니라
            System.out.printf("%d. %s - %s\n", b.getId(), b.getTitle(), userController.selectNicknameById(b.getWriterId())); // writerId를 가져오기 위해서 userController의 selectNicknameById()메소드를 호출해서 가져와야함
        }

        int choice = ScannerUtil.printInt(sc, "상세보기할 글의 번호(0. 뒤로가기)>");
        while (!boardController.validateInput(choice)) {
            System.out.println("잘못 입력");
            choice = ScannerUtil.printInt(sc, "상세보기할 글의 번호(0. 뒤로가기)>");
        }
        if (choice != 0) { // 상세보기할 글 번호 입력했을 때
            printOne(choice);

        } else { // 뒤로가기
            System.out.println("게시판 메인 메뉴로 돌아갑니다.");
            showMenu();
        }
    }

    private void printOne(int id) {
        BoardDTO boardDTO = boardController.selectOne(id); // 해당 id 값을 가진 DTO 저장
        System.out.println("=============================================");
        System.out.println("제목: " + boardDTO.getTitle());
        System.out.println("글 번호: " + boardDTO.getId());
        System.out.println("작성자: " + boardDTO.getWriterId());
        System.out.println("---------------------------------------------");
        System.out.println("내용: " + boardDTO.getContent());
        System.out.println("=============================================");

        // 댓글 출력
        replyViewer.setBoardDTO(boardDTO); // replyViewer에다가 boardDTO를 통째로 넘겨서 그 안에서 새로 호출해서 해결
        replyViewer.setLogIn(logIn);
        replyViewer.showReply();

        // 지금 로그인한 사람이 작성자가 아니라면 수정 삭제가 가능할 수 없도록 조건문 작성
        if (logIn.getId() == boardDTO.getWriterId()) {
            int choice = ScannerUtil.printInt(sc, "게시글 1. 수정 2. 삭제 3. 뒤로가기>", 1, 3);
            if (choice == 1) {
                update(choice); // 수정 메소드 실행
            } else if (choice == 2) {
                delete(choice); // 삭제 메소드 실행
            } else if (choice == 3) {
                printList();
            }
        } else {
            int choice = ScannerUtil.printInt(sc, "1. 뒤로 가기", 1, 1);
            if (choice == 1) printList();
        }
    }

    private void update(int id) {
        BoardDTO b = boardController.selectOne(id); // id값에 맞는 글 가져옴
        b.setTitle(ScannerUtil.printString(sc, "수정할 제목: "));
        b.setContent(ScannerUtil.printString(sc, "수정할 내용: "));
        boardController.update(b);

        System.out.println("게시글 수정 완료");
    }

    private void delete(int id) {
        String answer = ScannerUtil.printString(sc, "삭제하시겠습니까? (Y/N)>");
        if (answer.equalsIgnoreCase("Y")) {
            boardController.delete(logIn.getId());
            System.out.println("게시글 삭제 완료");
        } else printOne(id);
    }

}
