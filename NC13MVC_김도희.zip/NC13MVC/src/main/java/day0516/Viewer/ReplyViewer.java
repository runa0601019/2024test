package day0516.Viewer;

import day0516.Controller.BoardController;
import day0516.Controller.ReplyController;
import day0516.Controller.UserController;
import day0516.Model.BoardDTO;
import day0516.Model.ReplyDTO;
import day0516.Model.UserDTO;
import miniProject.ScannerUtil;
import lombok.Setter;

import java.util.ArrayList;
import java.util.Scanner;

public class ReplyViewer {
    @Setter
    private ReplyController replyController;
    @Setter
    private BoardController boardController;
    @Setter
    private UserController userController;
    @Setter
    private BoardViewer boardViewer;
    @Setter
    private UserViewer userViewer;
    @Setter
    private Scanner sc;
    @Setter
    private UserDTO logIn; // 로그인해서 적어야 하므로 가져옴
    @Setter
    private BoardDTO boardDTO;


    public void showReply() {  // 여기에 전달된 boardId는 BoardViewer에서 전달된 인자이며, 댓글을 확인할 게시글번호
        int boardId = boardDTO.getId();
        showBoardReply(boardId); // 입력된 댓글 우선 먼저 출력

        int choice = ScannerUtil.printInt(sc, "1. 해당 게시글 댓글 작성 2. 해당 게시글 내가 작성한 댓글 확인 3. 뒤로가기>", 1, 3); // 댓글이 작성되면 무조건 다 보여줘야함
        if (choice == 1) {
            insert(boardId);
        } else if (choice == 2) {
            showMyReply(boardId);
        } else if (choice == 3) {
            System.out.println("게시판 메뉴로 돌아갑니다.");
        }

    }

    // 1. 댓글 작성해서 해당 게시판에 넣기
    private void insert(int boardId) {
        ReplyDTO replyDTO = new ReplyDTO();

        replyDTO.setContent(ScannerUtil.printString(sc, "댓글 내용>"));
        // 닉네임 가져오기, 로그인 되어있는 사람의 id를 가져와서 그에 맞는 nickname을 반환하게 해야함
//        replyDTO.getWriterId(userController.selectNicknameById());
        replyDTO.setWriterId(logIn.getId()); // 댓글 작성자 아이디를 가져오기위해 logIn에서 아이디를 가져옴
        replyDTO.setBoardId(boardId); // 작성할 게시글의 아이디를 가져옴, boardId가 같은 애들끼리 묶기

        replyController.insert(replyDTO);
        System.out.println("댓글 작성 완료");
    }

    // 해당 게시글에 달린 모든 댓글을 모은 Array
    private ArrayList<ReplyDTO> boardReply(int boardId) {
        ArrayList<ReplyDTO> list = replyController.selectAll(); // 댓글을 전체 선택하고
        ArrayList<ReplyDTO> boardList = new ArrayList<>(); // boardId에 맞는 댓글을 출력하기 위해 댓글을 모아둘 boardlist 생성

        if (list.isEmpty()) System.out.println("아직 입력된 댓글 없습니다.");
        else { // 어디에든 입력된 댓글이 있다면

            for (ReplyDTO r : list) {
                if (boardId == r.getBoardId()) { // 만약 파라미터 boardId와 같은 boardId를 가진 댓글이 있다면
                    boardList.add(r); //boardList에 넣기
                }
            }
        }
        return boardList;
    }

    // 내가 게시글에 작성한 댓글을 모두 가져오는 ArrayList
    private ArrayList<ReplyDTO> myReply(int boardId) {
        ArrayList<ReplyDTO> list = boardReply(boardId); // 해당 게시글에 작성되어있는 모든 댓글을 가져오고
        ArrayList<ReplyDTO> myReply = new ArrayList<>(); // 내가 작성한 댓글을 출력하기 위해 댓글을 모아둘 myReply 생성

        if (list.isEmpty()) System.out.println("아직 입력한 댓글이 없습니다.");
        else { // 어디에든 입력한 댓글이 있다면
            for (ReplyDTO r : list) {
                if (logIn.getId() == r.getWriterId()) { // 만약 로그인한 사용자와 같은 아이디를 가진 사람의 댓글이 게시글에 있다면
                    myReply.add(r); // myReply에 넣기
                }
            }
        }
        return myReply;
    }

    // 해당 게시글에 달린 모든 댓글 출력하는 printList
    private void showBoardReply(int boardId) {
        ArrayList<ReplyDTO> list = boardReply(boardId);

        if (list.isEmpty()) System.out.println("아직 입력된 댓글 없습니다.");
        else {
            for (ReplyDTO r : list) {
                // 몇번째 댓글인지와 작성자 및 내용 출력
                System.out.println(r.getId() + "번 댓글>" + r.getWriterId() + ": " + r.getContent());
            }
        }
    }

    // 해당 게시글에 내가 작성한 댓글만 프린트
    private void showMyReply(int boardId) {
        ArrayList<ReplyDTO> list = myReply(boardId);
        if (list.isEmpty()) System.out.println("당신은" + boardId + "번 게시글에 아무런 댓글을 적지 않았습니다.");
        else {
            for (ReplyDTO r : list) {
                System.out.println(r.getId() + "번 댓글: " + r.getContent());
            }
            int num = ScannerUtil.printInt(sc, "수정/삭제할 댓글번호(0.뒤로가기)>");
            while (!replyController.validateInput(list, num)) {
                System.out.println("잘못된 입력");
                num = ScannerUtil.printInt(sc, "수정/삭제할 댓글번호(0.뒤로가기)>");
            }
            if (num != 0) {
                int choice = ScannerUtil.printInt(sc, "댓글 1. 수정 2. 삭제 3. 뒤로가기>", 1, 3);
                if (choice == 1) {
                    update(boardId, num); // 수정 메소드 실행
                } else if (choice == 2) {
                    delete(boardId, num); // 삭제 메소드 실행
                } else if (choice == 3) {
                    System.out.println("게시판 전체 댓글 출력으로 돌아갑니다.");
                    showBoardReply(boardId);
                }
            } else {
                System.out.println("댓글 메뉴로 돌아갑니다.");
                showReply();
            }
        }
    }

    // 댓글 수정메소드, 해당 게시글에 내가 작성한 댓글만 모아둔 ArrayList가 파라미터로 전달
    private void update(int boardId, int id) {
        ArrayList<ReplyDTO> list = myReply(boardId);
        ReplyDTO r = list.get(id);
        r.setContent(ScannerUtil.printString(sc, "수정할 댓글: "));
        replyController.update(r);
        System.out.println("댓글 수정 완료");
    }

    // 댓글 삭제메소드, 해당 게시글에 내가 작성한 댓글만 모아둔 ArrayList가 파라미터로 전달
    private void delete(int boardId, int id) {
        String answer = ScannerUtil.printString(sc, "삭제하시겠습니까? (Y/N)>");
        if (answer.equalsIgnoreCase("Y")) {
            replyController.delete(id);
            System.out.println("댓글 삭제 완료");
        } else {
            System.out.println("내 댓글 전체 출력으로 돌아갑니다.");
            showMyReply(boardId);
        }
    }
}




