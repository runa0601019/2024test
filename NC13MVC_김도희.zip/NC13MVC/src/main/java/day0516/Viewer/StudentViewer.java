package day0516.Viewer;

import day0516.Controller.StudentController;
import day0516.Model.StudentDTO;
import miniProject.ScannerUtil;

import java.util.ArrayList;
import java.util.Scanner;

public class StudentViewer {
    private final Scanner sc = new Scanner(System.in);
    private StudentController studentController; // db가 잇으면 매번 알아서 만들어지지만, 없기 때문에 요청을 받아서 처리하기 위해 우리가 만들어줘야함

    public StudentViewer(StudentController studentController) {
        this.studentController = studentController;
    }

    public void showMenu() {
        while (true) {
            int choice = ScannerUtil.printInt(sc, "1. 입력 2. 출력 2. 종료>", 1, 3);
            if (choice == 1) {
                insertStudent(); // 접근제한자가 private이 되어야 실행 가능
            } else if (choice == 2) {
//                printStudent();
                printList();
            } else if (choice == 3) {
                System.out.println("사용해주셔서 감사합니다.");
                break;
            }
        }
    }

    private void insertStudent() {
        StudentDTO s = new StudentDTO();
        String name = ScannerUtil.printString(sc, "이름: ");
        int korean = ScannerUtil.printInt(sc, "국어: ");
        int english = ScannerUtil.printInt(sc, "영어: ");
        int math = ScannerUtil.printInt(sc, "수학: ");

        s.setName(name);
        s.setKorean(korean);
        s.setEnglish(english);
        s.setMath(math);

        studentController.insert(s);
    }

    private void printList() {
        ArrayList<StudentDTO> list = studentController.selectAll();

        if (list.isEmpty()) System.out.println("아직 등록 정보 x");
        else {
            briefList(list);
            int choice = ScannerUtil.printInt(sc, "상세보기할 학생번호>");
            while (!validateValue(choice)) {
                System.out.println("잘못입력");
                choice = ScannerUtil.printInt(sc, "상세보기할 학생번호>");
            }
            if (choice != 0) {
                printOne(choice);
            }
        }
    }

    private void briefList(ArrayList<StudentDTO> list) {
        for (StudentDTO s : list) {
            System.out.printf("%d %s\n", s.getId(), s.getName());
        }
    }

    private boolean validateValue(int value) {
        if (value == 0) {
            return true;
        }
        return studentController.selectOne(value) != null;
    }

    private void printOne(int id) {
        StudentDTO s = studentController.selectOne(id);
        System.out.println(s.getName() + " 학생의 정보");
        System.out.printf("번호: %02d번 이름: %s\n", s.getId(), s.getName());
        System.out.printf("국어: %03d점 영어: %03d점 수학: %03d점\n", s.getKorean(), s.getEnglish(), s.getMath());
        System.out.printf("총점: %03d점 평균: %06.2f점\n", studentController.calculateSum(s), studentController.calculateAverage(s));

        int choice = ScannerUtil.printInt(sc, "1. 수정 2. 삭제 3. 뒤로가기", 1, 3);
        if (choice == 1) {
            update(id);
        } else if (choice == 2) {
            delete(id);
        } else if (choice == 3) {
            System.out.println("돌아갑니다.");
            printList();
        }
    }

    private void update(int id) {
        StudentDTO s = studentController.selectOne(id);
        System.out.println("새로운 정보 입력");
        s.setName(ScannerUtil.printString(sc, "이름: "));
        s.setKorean(ScannerUtil.printInt(sc, "국어: "));
        s.setEnglish(ScannerUtil.printInt(sc, "영어: "));
        s.setMath(ScannerUtil.printInt(sc, "수학: "));

        studentController.update(s);
        printOne(id);
    }

    private void delete(int id) {
        String answer = ScannerUtil.printString(sc, "정말로 삭제하시겠습니까? Y/N>");
        if (answer.equalsIgnoreCase("Y")) {
            studentController.delete(id);
            printList();
        } else {
            printOne(id);
        }
    }

    //내코드
//    private void printStudent() {
////        System.out.println(studentController.selectAll());
////
////        int id = ScannerUtil.printInt(sc, "수정 혹은 삭제를 원하는 인덱스(0. 뒤로가기)>");
////        if (!validate(id)) {
////            System.out.println("잘못된 입력입니다.");
////            id = ScannerUtil.printInt(sc, "수정 혹은 삭제를 원하는 인덱스(0. 뒤로가기)>");
////        }
////
////        if (id != 0) printOne(id);
////        else {
////            System.out.println("메인 화면으로 돌아갑니다.");
////            showMenu();
////        }
//    }
//
//    private boolean validate(int id) {
//        if(id==0) return true;
//        if (studentController.selectOne(id) != null) return true;
//        return false;
//    }
//
//    private void printOne(int id) {
//        int choice = ScannerUtil.printInt(sc, "1. 수정 2. 삭제 3. 종료>", 1, 3);
//        if (choice == 1) {
//            update(id);
//        } else if (choice == 2) {
//            delete(id);
//        } else if (choice == 3) {
//            System.out.println("출력 화면으로 돌아갑니다.");
//            printStudent();
//        }
//    }
//
//    private void update(int id) {
//        StudentDTO s = new StudentDTO();
//        s.setId(id);
//        System.out.println("수정 사항을 입력하세요.");
//        String name = ScannerUtil.printString(sc, "이름: ");
//        int korean = ScannerUtil.printInt(sc, "국어: ");
//        int english = ScannerUtil.printInt(sc, "영어: ");
//        int math = ScannerUtil.printInt(sc, "수학: ");
//
//        s.setName(name);
//        s.setKorean(korean);
//        s.setEnglish(english);
//        s.setMath(math);
//
//        studentController.update(s);
//        System.out.println("수정을 완료하였습니다. 출력화면으로 돌아갑니다.");
//        printStudent();
//    }
//
//    private void delete(int id) {
//        studentController.delete(id);
//        System.out.println("삭제를 완료하였습니다. 출력화면으로 돌아갑니다.");
//        printStudent();
//    }
}