package day0516.main;

import day0516.Controller.BoardController;
import day0516.Controller.ReplyController;
import day0516.Controller.UserController;
import day0516.Model.BoardDTO;
import day0516.Model.UserDTO;
import day0516.Viewer.BoardViewer;
import day0516.Viewer.ReplyViewer;
import day0516.Viewer.UserViewer;

import java.util.Scanner;

public class BoardMain {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in); // 입력에 사용할 Scanner 객체

        // 각종 컨트롤러 클래스 객체
        UserController userController = new UserController();
        BoardController boardController = new BoardController();
        ReplyController replyController = new ReplyController();

        // 각종 뷰어 클래스 객체
        UserViewer userViewer = new UserViewer();
        BoardViewer boardViewer = new BoardViewer();
        ReplyViewer replyViewer = new ReplyViewer();

        // setter를 사용한 의존성 주입
        userViewer.setSc(sc);
        userViewer.setUserController(userController);
        userViewer.setBoardViewer(boardViewer); // 게시판관련 처리를 위해서
        userViewer.setReplyViewer(replyViewer); // 댓글관련 처리

        boardViewer.setSc(sc);
        boardViewer.setBoardController(boardController); // controller와 viewer는 애초에 의존관계
        boardViewer.setUserController(userController); // userController에서 회원정보를 가져와 boardViewer에 저장해주기 위해 의존성 주입
        boardViewer.setReplyViewer(replyViewer); // boardViewer에서 replyViewer의 메소드를 이용해야 하기때문에 의존성 주입
        boardViewer.setReplyController(replyController);//x

        replyViewer.setSc(sc);
        replyViewer.setReplyController(replyController);
        replyViewer.setBoardController(boardController);
        replyViewer.setUserController(userController);

        userViewer.showIndex();
        // boardViewer.showMenu(); 는 logIn 정보가 있어야 실행되기 때문에 이렇게 실행될 수 없음
    }
}
