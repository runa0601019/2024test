package day0516.main;

import day0516.Controller.StudentController;
import day0516.Viewer.StudentViewer;

public class StudentMain {
    public static void main(String[] args) {
        StudentController studentController = new StudentController();
        StudentViewer studentViewer = new StudentViewer(studentController);

        studentViewer.showMenu();
    }
}
