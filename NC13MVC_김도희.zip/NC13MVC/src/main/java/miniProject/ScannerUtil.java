package miniProject;
// 스캐너 클래스를 사용할 때 좀 더 간편하게 사용할 수 있는 메소드들을 모아둔 클래스

// 현재 ScannerUtil의 메소드는 완벽하지만 사용자의 입력이 온전하지 않을 경우 에러가 발생하기 때문에,
// RegEx에서 썻던 것을 이용해서 값이 어떤것으로 이루어져있는지 확인하고 ture false값을 받아 재입력을 유도할 수 있다.


import java.util.Scanner;

public class ScannerUtil {

    public static void print(String message) {
        System.out.println(message);
    }

    // 출력에 사용할 메시지를 받아서 예쁘게 출력해줄 메소드, 파라미터로는 String이 필요하고 출력메시지를 보여줄 것이기 때문에 void 형태로 만든다
    private static void printMessage(String message) {
        System.out.print(message);
    }

    public static int printInt(Scanner sc, String message1) { // 수업에서는 nextInt로 메소드 이름 썼지만, 함수랑 이름 동일하기 때문에 변경해줌
        printMessage(message1); // 위의 메소드를 통해 nextInt에 들어온 message1 처리
        int temp = sc.nextInt();
        return temp; // 스캐너로 받아 int형으로 바로 보내주기
    }

    public static String printString(Scanner sc, String message1) { // 수업에서는 nextLine로 메소드 이름 썼지만, 함수랑 이름 동일하기 때문에 변경해줌
        printMessage(message1); // 위의 메소드를 통해 nextInt에 들어온 message1 처리
        String temp = sc.nextLine();
        if (temp.isEmpty()) { // 공백입력되었을 때를 방지하기 위해 한번 더 입력하도록 함
            temp = sc.nextLine();
        }
        return temp; // 스캐너로 받아 string형으로 바로 보내주기
    }

    // 사용자가 스캐너, 메시지, 최소값, 최대값을 보내면 해당 범위의 정수를 리턴해주는 메소드
    public static int printInt(Scanner sc2, String message2, int min, int max) { // 수업에서는 nextInt로 메소드 이름 썼지만, 함수랑 이름 동일하기 때문에 변경해줌
        // RegEx 사용한 printInt
        String temp = printString(sc2, message2);
        while (!temp.matches("^-?\\d+$")) { // 음수가 나올수도 잇고 안나올수도 있기 때문에 -앞에 ?붙여서 0번 혹은 양수가 나오는지 확인해준다는 뜻, \\d 붙여서 정수인지 확인하고 +붙여 1개 이상의 숫자인지 확인해줌
            System.out.println("숫자가 아닙니다.\n다시 입력해주세요.");
            temp = printString(sc2, message2);
        }
        return Integer.parseInt(temp); // String을 int로 바꿀때는 Integet.parseInt(String)사용
    }

    public static int printint(Scanner sc, String message, int min, int max){
        //기존 printInt
        int temp = printInt(sc, message); // printInt안에 printMessage가 있어 하나 호출만으로 2개가 다 실행됨
        while (!(temp >= min && temp <= max)) { // temp가 최소값과 최대값 사이의 값이 아닐 경우
            System.out.println("범위를 벗어난 값입니다.");
            temp = printInt(sc, message);
        }

        return temp; // 올바른 범위안의 temp return
    }


    public static double printDouble(Scanner sc3, String message3) { // 수업에서는 nextInt로 메소드 이름 썼지만, 함수랑 이름 동일하기 때문에 변경해줌
        printMessage(message3); // 위의 메소드를 통해 nextInt에 들어온 message1 처리
        double temp = sc3.nextInt();
        return temp; // 스캐너로 받아 int형으로 바로 보내주기
    }


    // 사용자가 스캐너, 메시지, 최소값, 최대값을 보내면 해당 범위의 실수를 리턴해주는 메소드
    public static double printDouble(Scanner sc3, String message3, double min, double max) { // 수업에서는 nextInt로 메소드 이름 썼지만, 함수랑 이름 동일하기 때문에 변경해줌
        double temp = printDouble(sc3, message3); // printInt안에 printMessage가 있어 하나 호출만으로 2개가 다 실행됨
        while (!(temp >= min && temp <= max)) { // temp가 최소값과 최대값 사이의 값이 아닐 경우
            System.out.println("범위를 벗어난 값입니다.");
            temp = printDouble(sc3, message3);
        }
        return temp;
//        return Double.parseDouble(temp); // String을 int로 바꿀때는 Integet.parseInt(String)사용
    }

}