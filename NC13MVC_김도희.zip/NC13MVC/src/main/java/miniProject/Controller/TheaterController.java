package miniProject.Controller;

import miniProject.Model.MovieDTO;
import miniProject.Model.ReviewDTO;
import miniProject.Model.TheaterDTO;
import miniProject.Model.UserDTO;

import java.util.ArrayList;
import java.util.Objects;

public class TheaterController {
    private ArrayList<TheaterDTO> list;
    private int nextId;
    private TheaterController movieController;

//    public TheaterController() {
//        list = new ArrayList<>();
//        nextId = 1;
//    }

    public TheaterController() {
        list = new ArrayList<>();
        nextId = 3;

        //!!!!!!!!!!!!!!!!!!!!!!!!!!!!!test
        TheaterDTO t = new TheaterDTO();
        t.setId(1);
        t.setName("CGV대학로");
        t.setLocation("서울특별시 종로구 명륜2가 41-9");
        t.setCallNumber("0215441122");
        list.add(t);

        TheaterDTO t1 = new TheaterDTO();
        t1.setId(2);
        t1.setName("megabox 코엑스");
        t1.setLocation("서울특별시 강남구 봉은사로524");
        t1.setCallNumber("0215440070");
        list.add(t1);
        //!!!!!!!!!!!!!!!!!!!!!!!!!!!!!test
    }

    public void insert(TheaterDTO theaterDTO) {
        theaterDTO.setId(nextId++);
        list.add(theaterDTO);
    }

    public TheaterDTO selectOne(int id) {
        TheaterDTO temp = new TheaterDTO();
        temp.setId(id);
        if (list.contains(temp)) {
            return list.get(list.indexOf(temp));
        }
        return null;
    }

    public ArrayList<TheaterDTO> selectAll() {
        return list;
    }

    public void update(TheaterDTO theaterDTO) {
        list.set(list.indexOf(theaterDTO), theaterDTO);
    }

    public void delete(int id) {
        TheaterDTO theaterDTO = new TheaterDTO();
        theaterDTO.setId(id);
        list.remove(theaterDTO);
    }

    public boolean validateInput(int input) {
        if (input == 0) return true;

        TheaterDTO theaterDTO = new TheaterDTO();
        theaterDTO.setId(input);
        return list.contains(theaterDTO); // input을 아이디로 가지고 있는 boardDTO가 있는지 확인해서 그 값을 리턴
    }

//    // 상영관에서 상영하지않는 영화 list, 상영관 전체 리스트에서 전달받은 상영관 아이디를 갖고잇는 애들만 리스트에 넣기
//    public ArrayList<TheaterDTO> movieList(int theaterId) {
//        ArrayList<TheaterDTO> list = selectAll();
////        ArrayList<MovieDTO> list = movieController.selectAll(); // 전체 평가를 입력 list안에 넣고
//        ArrayList<TheaterDTO> movieList = new ArrayList<>(); // 조건에 맞는 평가를 넣을 list를 하나 만듦
//        if (Objects.requireNonNull(list).isEmpty()) {
//            return null;
//        }
//
//        for (TheaterDTO t : list) { // 상영관 list에서 파라미터로 받은 상영관 같은 애들만 반환
//            if (t.getMovieId() != theaterId)
//                movieList.add(t);
//        }
//        return movieList;
//    }
}
