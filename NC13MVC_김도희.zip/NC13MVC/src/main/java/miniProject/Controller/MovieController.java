package miniProject.Controller;

import lombok.Setter;
import miniProject.Model.MovieDTO;
import miniProject.Model.ReviewDTO;
import miniProject.Model.TheaterDTO;

import java.util.ArrayList;
import java.util.Objects;

public class MovieController {
    private ArrayList<MovieDTO> list;
    private int nextId;

//    public MovieController() {
//        list = new ArrayList<>();
//        nextId = 1;
//    }

    // test!!!!!!!!!!!!!!!!!!!!!!
    public MovieController() {
        list = new ArrayList<>();
        nextId = 3;

        MovieDTO m = new MovieDTO();
        m.setId(1);
        m.setTitle("그녀가 죽었다");
        m.setSummary("“나쁜 짓은 절대 안 해요. 그냥 보기만 하는 거예요.”\n" +
                "\n" +
                "고객이 맡긴 열쇠로 그 집에 들어가\n" +
                "남의 삶을 훔쳐보는 취미를 지닌 공인중개사 ‘구정태’.\n" +
                "편의점 소시지를 먹으며 비건 샐러드 사진을 포스팅하는\n" +
                "SNS 인플루언서 ‘한소라’에게 흥미를 느끼고 관찰하기 시작한다.\n" +
                "\n" +
                "“관찰 152일째, 그녀가… 죽었습니다.”\n" +
                "\n" +
                "급기야 ‘한소라’의 집까지 드나들던 ‘구정태’는\n" +
                "어느 날, 그녀가 소파에 죽은 채 늘어져 있는 모습을 발견하게 된다.\n" +
                "\n" +
                "그 후 그가 ‘한소라’ 집에 들어간 것을 알고 있는 누군가가 협박을 시작하고,\n" +
                "사건을 맡은 강력반 형사 ‘오영주’의 수사망이 그를 향해 좁혀온다.\n" +
                "스스로 범인을 찾아야 하는 ‘구정태’는 ‘한소라’의 SNS를 통해\n" +
                "주변 인물들을 뒤지며 진범을 찾아 나서는데…");
        list.add(m);


        MovieDTO m1 = new MovieDTO();
        m1.setId(2);
        m1.setTitle("퓨리오사-매드맥스 사가");
        m1.setSummary("문명 붕괴 45년 후,\n" +
                "\n" +
                "황폐해진 세상 속 누구에게도 알려지지 않은\n" +
                "풍요가 가득한 ‘녹색의 땅’에서 자란 ‘퓨리오사’(안야 테일러-조이)는\n" +
                "바이커 군단의 폭군 ‘디멘투스’(크리스 헴스워스)의 손에 모든 것을 잃고 만다.\n" +
                "\n" +
                "가족도 행복도 모두 빼앗기고 세상에 홀로 내던져진 ‘퓨리오사’는\n" +
                "반드시 고향으로 돌아가겠다는 어머니와의 약속을 지키기 위해\n" +
                "인생 전부를 건 복수를 시작하는데...\n" +
                "\n" +
                "‘매드맥스’ 시리즈의 전설적인 사령관 ‘퓨리오사’의 대서사시\n" +
                "5월 22일, 마침내 분노가 깨어난다!");
        list.add(m1);

    }
    // test!!!!!!!!!!!!!!!!!!!!!!

    public void insert(MovieDTO movieDTO) {
        movieDTO.setId(nextId++);
        list.add(movieDTO);
    }

    public MovieDTO selectOne(int id) {
        MovieDTO temp = new MovieDTO();
        temp.setId(id);

        if (list.contains(temp)) {
            return list.get(list.indexOf(temp));
        }
        return null;
    }

    public ArrayList<MovieDTO> selectAll() {
        return list;
    }

    public void update(MovieDTO movieDTO) {
        list.set(list.indexOf(movieDTO), movieDTO);
    }

    public void delete(int id) {
        MovieDTO movieDTO = new MovieDTO();
        movieDTO.setId(id);
        list.remove(movieDTO);
    }

    //실제로 존재하는 영화인지 확인하기 위함
    public boolean validateInput(int input) {
        if (input == 0) return true;

        MovieDTO movieDTO = new MovieDTO();
        movieDTO.setId(input);
        return list.contains(movieDTO); // input을 아이디로 가지고 있는 boardDTO가 있는지 확인해서 그 값을 리턴
    }
}
