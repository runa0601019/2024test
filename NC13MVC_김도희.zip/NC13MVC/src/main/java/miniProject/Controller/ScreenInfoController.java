package miniProject.Controller;

import miniProject.Model.MovieDTO;
import miniProject.Model.ScreenInfoDTO;
import miniProject.Model.TheaterDTO;

import java.util.ArrayList;
import java.util.Objects;

public class ScreenInfoController {
    private ArrayList<ScreenInfoDTO> list;
    private int nextId;
    private TheaterController theaterController;

    public ScreenInfoController() {
        list = new ArrayList<>();
        nextId = 1;
    }

    public void insert(ScreenInfoDTO screenInfoDTO) {
        screenInfoDTO.setId(nextId++);
        list.add(screenInfoDTO);
    }

    public ScreenInfoDTO selectOne(int id) {
        ScreenInfoDTO temp = new ScreenInfoDTO();
        temp.setId(id);

        if (list.contains(temp)) {
            return list.get(list.indexOf(temp));
        }
        return null;
    }

    public ArrayList<ScreenInfoDTO> selectAll() {
        return list;
    }

    public void update(ScreenInfoDTO replyDTO) {
        list.set(list.indexOf(replyDTO), replyDTO);
    }

    public void delete(int id) {
        ScreenInfoDTO s = new ScreenInfoDTO();
        s.setId(id);
        list.remove(s);
    }

    public boolean validateInput(int input) {
        if (input == 0) return true;

        ScreenInfoDTO screenInfoDTO = new ScreenInfoDTO();
        screenInfoDTO.setId(input);
        return list.contains(screenInfoDTO); // input을 아이디로 가지고 있는 boardDTO가 있는지 확인해서 그 값을 리턴
    }

    // 상영정보리스트에서 파라미터와 같은 영화id를 가진 애들만 리스트에 넣기
    // 영화id와 같은 상영정보만을 반환
    public ArrayList<ScreenInfoDTO> movieList(int movieId) {
        ArrayList<ScreenInfoDTO> list = selectAll(); // 전체를 list안에 넣고
        ArrayList<ScreenInfoDTO> screenInfoList = new ArrayList<>(); // 조건에 맞는 DTO를 넣을 list를 하나 만듦

        for (ScreenInfoDTO s : list) { // 상영시간표중 상영관의 상영되는 영화와
            if (s.getMovieId() == movieId) // movieId가 같다면
                screenInfoList.add(s);
        }

        if (screenInfoList.isEmpty()) {
            return null;
        }else{
            return screenInfoList;
        }


    }

    // 상영정보리스트에서 파라미터와 같은 상영관id를 가진 애들만 리스트에 넣기
    public ArrayList<ScreenInfoDTO> theaterList(int theaterId) {
        ArrayList<ScreenInfoDTO> list = selectAll(); // 전체를 list안에 넣고
        ArrayList<ScreenInfoDTO> screenInfoList = new ArrayList<>(); // 조건에 맞는 DTO를 넣을 list를 하나 만듦

        for (ScreenInfoDTO s : list) { // 상영시간표중 상영관의 상영되는 영화와
            if (s.getTheaterId() == theaterId) // theaterId가 같다면
                screenInfoList.add(s);
        }

        if (screenInfoList.isEmpty()) {
            return null;
        }else{
            return screenInfoList;
        }
    }
}
