package miniProject.Controller;
// 평점 컨트롤러

import miniProject.Model.ReviewDTO;

import java.util.ArrayList;
import java.util.Objects;

public class ReviewController {
    private ArrayList<ReviewDTO> list;
    private int nextId;

    public ReviewController() {
        list = new ArrayList<>();
        nextId = 1;
    }

    public void insert(ReviewDTO reviewDTO) {
        reviewDTO.setId(nextId++);
        list.add(reviewDTO);
    }

    public ReviewDTO selectOne(int id) {
        ReviewDTO temp = new ReviewDTO();
        temp.setId(id);

        if (list.contains(temp)) {
            return list.get(list.indexOf(temp));
        }
        return null;
    }

    public ArrayList<ReviewDTO> selectAll() {
        return list;
    }

    public void update(ReviewDTO reviewDTO) {
        list.set(list.indexOf(reviewDTO), reviewDTO);
    }

    public void delete(int id) {
        ReviewDTO reviewDTO = new ReviewDTO();
        reviewDTO.setId(id);
        list.remove(reviewDTO);
    }

    public boolean validateInput(ArrayList<ReviewDTO> list, int input) {
        if (input == 0) return true;

        ReviewDTO reviewDTO = new ReviewDTO();
        reviewDTO.setId(input);
        return list.contains(reviewDTO); // input을 아이디로 가지고 있는 boardDTO가 있는지 확인해서 그 값을 리턴
    }

    public double sum(ArrayList<ReviewDTO> list) {
        if (list.isEmpty()) {
            return -1;
        } else {
            double sum = 0;
            for (ReviewDTO r : list) {
                sum += r.getGrade();
            }
            return sum;
        }
    }

    public double avg(ArrayList<ReviewDTO> list) {
        if (list.isEmpty()) {
           return -1;
        } else {
            return sum(list) / list.size();
        }
    }

    // 영화 평점 반환하는 메소드
    public double selectGrade(int movieId) {
        ArrayList<ReviewDTO> list = selectAll(); // 전체 평가를 입력 list안에 넣고
        ArrayList<ReviewDTO> reviewList = new ArrayList<>(); // 조건에 맞는 평가를 넣을 list를 하나 만듦
        while (Objects.requireNonNull(list).isEmpty()) {
            System.out.println("아직 작성된 리뷰가 없습니다.");
        }

        for (ReviewDTO r : list) {
            if (r.getMovieId() == movieId)
                reviewList.add(r);
        }

        return avg(reviewList);
    }

    public ArrayList<ReviewDTO> movieReviewByRank(int movieId, int rank) {
        ArrayList<ReviewDTO> list = selectAll(); // 전체 평가를 입력 list안에 넣고
        ArrayList<ReviewDTO> reviewList = new ArrayList<>(); // 조건에 맞는 평가를 넣을 list를 하나 만듦

        if (Objects.requireNonNull(list).isEmpty()) {
            return null;
        } else {
            if (rank == 3) { // 전체 평가를 출력하는 경우 영화아이디가 같은 경우만 찾아서 list.add해주면 됨
                for (ReviewDTO r : list) {
                    if (r.getMovieId() == movieId)
                        reviewList.add(r);
                }
            } else { // 그게 아닐 경우에는 rank==1 rank==2일 경우로 나누어서 넣어줌
                for (ReviewDTO r : list) {
                    if (r.getMovieId() == movieId && r.getRank() == rank) {
                        reviewList.add(r);
                    }
                }
            }
            return reviewList;
        }
    }
}
