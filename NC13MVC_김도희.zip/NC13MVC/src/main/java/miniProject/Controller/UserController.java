package miniProject.Controller;

import miniProject.Model.MovieDTO;
import miniProject.Model.UserDTO;

import java.util.ArrayList;

public class UserController {
    private ArrayList<UserDTO> list;
    private int nextId;

    public UserController() {
        list = new ArrayList<>();
        nextId = 4;

        UserDTO u = new UserDTO();
        u.setId(0);
        u.setUsername("0");
        u.setPassword("0");
        u.setNickname("관리자");
        u.setRank(5);
        list.add(u);

        UserDTO u1 = new UserDTO();
        u1.setId(1);
        u1.setUsername("1");
        u1.setPassword("1");
        u1.setNickname("1");
        u1.setRank(1);
        list.add(u1);

        UserDTO u2 = new UserDTO();
        u2.setId(2);
        u2.setUsername("2");
        u2.setPassword("2");
        u2.setNickname("2");
        u2.setRank(2);
        list.add(u2);

        UserDTO u3 = new UserDTO();
        u3.setId(3);
        u3.setUsername("3");
        u3.setPassword("3");
        u3.setNickname("3");
        u3.setRank(1);
        list.add(u3);
    }

    //    public UserController() {
//        list = new ArrayList<>();
//        nextId = 1;
//        // 관리자 삽입
//        UserDTO u = new UserDTO();
//        u.setId(0);
//        u.setUsername("0");
//        u.setPassword("0");
//        u.setNickname("관리자");
//        u.setRank(5);
//        list.add(u);
//    }
    public void insert(UserDTO userDTO) {
        userDTO.setId(nextId++);
        userDTO.setRank(1); // 맨처음 가입하면 무조건 일반회원, 관리자의 승인이 있을 때만 변경가능
        list.add(userDTO);
    }

    // 가입자 이름(=아이디) 중복되지 않도록
    public boolean validateUsername(String username) {
        for (UserDTO u : list) {
            if (u.getUsername().equalsIgnoreCase(username))
                return false;
        }

        return true;
    }

    // 회원 번호 겹치는 값 찾아내기
    public UserDTO selectOne(int id) {
        UserDTO temp = new UserDTO();
        temp.setId(id);
        if (list.contains(temp)) {
            return list.get(list.indexOf(temp));
        }
        return null;
    }

    public ArrayList<UserDTO> selectAll() {
        return list;
    }

    // 수정
    public void update(UserDTO userDTO) {
        list.set(list.indexOf(userDTO), userDTO);
    }

    // 삭제
    public void delete(int id) {
        UserDTO temp = new UserDTO();
        temp.setId(id);
        list.remove(temp);
    }

    // logIn 유지하기 위함
    public UserDTO auth(String username, String password) {
        for (UserDTO u : list) {
            if (username.equalsIgnoreCase(u.getUsername()) && password.equalsIgnoreCase(u.getPassword())) {
                return u;
            }
        }

        return null;
    }

    // logOut
    public UserDTO logOut(String answer, UserDTO u) {
        if (answer.equalsIgnoreCase("Y"))
            return null;
        else return u;
    }

    // 아이디에 맞는 nickname 가져오는 메소드
    public String selectNicknameById(int id) {
        UserDTO userDTO = new UserDTO();
        userDTO.setId(id);

        return list.get(list.indexOf(userDTO)).getNickname();
    }

    public boolean validateInput(int input) {
        if (input == 0) return true;

        UserDTO userDTO = new UserDTO();
        userDTO.setId(input);
        return list.contains(userDTO); // input을 아이디로 가지고 있는 boardDTO가 있는지 확인해서 그 값을 리턴
    }

    // 관리자 존재하는지 확인하기 위함
    public boolean isRank() {
        ArrayList<UserDTO> list = selectAll();
        boolean isContains = true;
        for (UserDTO u : list) {
            if (u.getRank() == 5) {
                isContains = false;
            }
        }
        return isContains;
    }

    // 관리자만 등급 변경, 굳이 필요없을듯,,
//    public UserDTO changeRank(UserDTO userDTO, int rank) {
//        UserDTO u = new UserDTO();
//        u.setId(userDTO.getId()); // 전달된 회원의 정보의 id를 새로운 객체 u의 id로 설정
//        u.setRank(rank);
//
//        return u;
//    }
}
