package miniProject.Model;

import lombok.Data;

@Data
public class UserDTO {
    private int id;
    private String username;
    private String password;
    private String nickname;
    private int rank; // rank가 1==일반관람객, 2==전문평론가, 5==관리자

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;

        if (o instanceof UserDTO) {
            UserDTO u = (UserDTO) o;
            return id == u.id;
        }

        return false;
    }
}
