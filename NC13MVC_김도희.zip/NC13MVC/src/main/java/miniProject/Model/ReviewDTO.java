package miniProject.Model;

import lombok.Data;

@Data
public class ReviewDTO {
    private int id;
    private int writerId; // 작성자의 아이디 가져옴
    private int movieId; // 평론을 작성한 영화 아이디 가져옴
    private String review; // 평가
    private double grade; // 등급 입력받기 위함

    private int rank; // 평론가인지 일반 회원인지 구분하기 위함
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;

        if (o instanceof ReviewDTO) {
            ReviewDTO reviewDTO = (ReviewDTO) o;
            return id == reviewDTO.id;
        }

        return false;
    }
}
