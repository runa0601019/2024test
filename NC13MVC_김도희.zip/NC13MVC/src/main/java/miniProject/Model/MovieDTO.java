package miniProject.Model;

import lombok.Data;

@Data
public class MovieDTO {
    private int id;
    private String title;
    private String summary;
    private double grade;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;

        if (o instanceof MovieDTO) {
            MovieDTO movieDTO = (MovieDTO) o;
            return id == movieDTO.id;
        }

        return false;
    }
}
