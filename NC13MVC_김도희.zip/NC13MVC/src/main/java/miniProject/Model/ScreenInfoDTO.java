package miniProject.Model;
// 상영정보

import lombok.Data;

@Data
public class ScreenInfoDTO {
    private int id;
    private int movieId;
    private int theaterId;
    private int time;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o instanceof ScreenInfoDTO) {
            ScreenInfoDTO s = (ScreenInfoDTO) o;
            return id == s.id;
        }
        return false;
    }
}
