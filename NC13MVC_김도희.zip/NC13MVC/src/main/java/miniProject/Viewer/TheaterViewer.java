package miniProject.Viewer;

import miniProject.ScannerUtil;
import lombok.Setter;
import miniProject.Controller.MovieController;
import miniProject.Controller.ScreenInfoController;
import miniProject.Controller.TheaterController;
import miniProject.Model.MovieDTO;
import miniProject.Model.ScreenInfoDTO;
import miniProject.Model.TheaterDTO;
import miniProject.Model.UserDTO;

import java.util.ArrayList;
import java.util.Scanner;

@Setter
public class TheaterViewer {
    private Scanner sc;
    private UserDTO logIn;
    private MovieViewer movieViewer;
    private TheaterController theaterController;
    private MovieController movieController;
    private UserViewer userViewer;
    private ScreenInfoController screenInfoController;
    private ScreenInfoViewer screenInfoViewer;

    public void showTheater() {
        while (logIn != null) {
            if (logIn.getRank() == 5) {
                System.out.println("<관리자 모드>");
            } else {
                System.out.println("<일반 모드>");
            }

            ArrayList<TheaterDTO> list = theaterController.selectAll();
            // 등록된 상영관 없다면
            if (list.isEmpty()) {
                System.out.println(">>>아직 등록된 상영관이 없습니다.");

                if (logIn.getRank() == 5) { // 관리자라면 등록화면 띄우기
                    String answer = ScannerUtil.printString(sc, "상영관을 등록하시겠습니까? (Y/N)>");
                    if (answer.equalsIgnoreCase("Y")) {
                        insertTheater();
                    } else {
                        System.out.println(">>>영화 및 상영관 관리 화면으로 돌아갑니다.\n");
                        userViewer.select();
                        break;
                    }
                } else { // 일반 회원이라면 다시 선택지로
                    System.out.println(">>>영화 및 상영관 화면으로 돌아갑니다.\n");
                    userViewer.select();
                    break;
                }
            }
            // 등록된 상영관 있다면
            else {
                System.out.println("=======================");
                System.out.println("  전체 상영관 목록 출력");
                for (TheaterDTO t : list) {
                    System.out.println("-----------------------");
                    System.out.printf("%d. %s\n", t.getId(), t.getName());
                }
                System.out.println("=======================");

                if (logIn.getRank() == 5) { // 관리자라면
                    int select = ScannerUtil.printint(sc, "1. 새로운 상영관 추가 2. 기존 상영관 상세보기 (0. 뒤로가기)>", 0, 2);
                    System.out.println();
                    if (select == 1) { // 새로운 상영관 추가
                        insertTheater();
                    } else if (select == 2) { // 기존 상영관 상세보기
                        int choice = ScannerUtil.printInt(sc, "상세보기할 상영관 번호 입력 (0. 뒤로가기)>");
                        while (!theaterController.validateInput(choice)) {
                            choice = ScannerUtil.printInt(sc, "존재하지 않는 상영관, 다시 입력>");
                        }
                        System.out.println();
                        if(choice!=0)
                        printTheater(choice);
                        else System.out.println(">>>상영관 관리 화면으로 돌아갑니다.\n");
                    } else { // 뒤로가기
                        System.out.println(">>>영화 및 상영관 관리 화면으로 돌아갑니다.\n");
                        break;
                    }
                } else { // 일반 회원이라면
                    int choice = ScannerUtil.printInt(sc, "상세보기할 상영관 번호 입력 (0. 뒤로가기)>");

                    while (!movieController.validateInput(choice)) {
                        choice = ScannerUtil.printInt(sc, "존재하지 않는 영화, 재입력>");
                    }
                    System.out.println();
                    if (choice != 0) {
                        printTheater(choice);
                    } else { // 뒤로가기
                        System.out.println(">>>영화 및 상영관 목록으로 돌아갑니다.\n");
                        break;
                    }
                }
            }
        }
    }


    private void printTheater(int choice) {
        // 상영관 선택했다면
        if (choice != 0) {
            TheaterDTO t = theaterController.selectOne(choice); // 선택한 상영관 객체 프린트
            System.out.println("=================================");
            System.out.print(t.getId() + ". " + t.getName() + "\n위치: " + t.getLocation() + "\n연락처: ");
            // 연락처 00-000-0000형식으로 출력하기 위함
            int i = 0;
            for (int j = 0; j < t.getCallNumber().length(); j++) {
                if (i == 2 || i == 6) {
                    System.out.print("-");
                    System.out.print(t.getCallNumber().charAt(j));
                } else if (i < 2 && j < 2) {
                    System.out.print(t.getCallNumber().charAt(j));
                } else if (i < 6 && j < 6) {
                    System.out.print(t.getCallNumber().charAt(j));
                } else {
                    System.out.print(t.getCallNumber().charAt(j));
                }
                i++;
            }
            System.out.println("\n=================================");

            // 관리자라면 영화 있든 없든 상영관 수정,삭제,새로운영화상영,기존상영영화수정
            if (logIn.getRank() == 5) {
                controlTheater(choice);
            } else {
                printScreenInfo(choice);
                System.out.println(">>>상영관 목록으로 돌아갑니다.");
            }
//            else {
//                selectTheater(choice);
//            }
        }
        // 뒤로가기
        else {
            System.out.println(">>>상영관 목록으로 돌아갑니다.\n");
        }
    }

    public void printScreenInfo(int theaterId) {
        // 선택된 상영관에서 상영하는 영화의 시간표를 가져와야함
        TheaterDTO t = theaterController.selectOne(theaterId);
        ArrayList<ScreenInfoDTO> screenList = screenInfoController.theaterList(theaterId); // 상영관 영화 시간표

        System.out.println("===========================================");
        System.out.println(t.getName() + "에서 상영중인 영화 목록");
        if (screenList != null) {  // 선택한 상영관에서 상영중인 영화가 있다면
            for (ScreenInfoDTO s : screenList) { // 선택한 상영관에서 상영중인 영화의 제목, 상영시간 보여주기
                MovieDTO m = movieController.selectOne(s.getMovieId());
                System.out.println("-------------------------------------------");
                System.out.println(s.getId() + ". 제목: " + m.getTitle() + " 상영시간: " + s.getTime());
            }
            System.out.println("===========================================");
//                if (logIn.getRank() != 5) { // 일반 회원이라면 있을 때만 예매로 넘어감
//                    selectTheater(choice);
//                    System.out.println(">>>예매 완료\n");
//                }
        } else { // 선택한 상영관에서 상영중인 영화가 없다면
            System.out.println("-------------------------------------------");
            System.out.println("상영 중인 영화가 없습니다.");
            System.out.println("===========================================");

            if (logIn.getRank() != 5) { // 일반 회원이라면 없을땐 다시 초기화면으로 돌아감
                System.out.println(">>>영화 및 상영관 화면으로 돌아갑니다.\n");
                System.out.println("어쩌구저쩌구");
                userViewer.select();
            }
        }
    }

    // 일반 회원 영화 예매하도록 하는 메소드
    private void selectTheater(int theaterId) {
        printScreenInfo(theaterId); // 상영정보 프린트해주기

        TheaterDTO t = theaterController.selectOne(theaterId);
        screenInfoViewer.setLogIn(logIn);
        screenInfoViewer.setT(t);
        screenInfoViewer.showScreenInfo();
    }

    // 관리자일 경우 실행되는 메소드-------------------------------------------------------

    // 상영관 삽입
    private void insertTheater() {
        TheaterDTO t = new TheaterDTO();
        t.setName(ScannerUtil.printString(sc, "등록할 상영관 이름: "));
        t.setLocation(ScannerUtil.printString(sc, "등록할 상영관 위치: "));
        String num = ScannerUtil.printString(sc, "등록할 상영관 연락처(지역번호 포함 10자리): ");
        while (num.length() != 10) {
            num = ScannerUtil.printString(sc, "잘못된 연락처입니다. 10자리로 다시 입력해주세요>");
        }
        t.setCallNumber(num);
        // 평점은 아직 등록되지 않았기 때문에 세팅하지 x

        theaterController.insert(t);
        System.out.println(">>>상영관 등록 완료\n");
//        userViewer.select();
    }

    // 상영관 수정 삭제 새로운 영화상영
    private void controlTheater(int theaterId) {
        int choice = ScannerUtil.printint(sc, "1. 상영관 수정 2. 상영관 삭제 3. 상영중인 영화 보기 (0. 뒤로가기)>", 0, 3);
        System.out.println();
        TheaterDTO t = theaterController.selectOne(theaterId); // 영화관의 정보는 넘겨줘야함, 영화는 들어가서 선택하면 됨

        if (choice == 1) {
            updateTheater(theaterId);
        } else if (choice == 2) { // 관리자가 영화를 삭제하게 되면 리뷰도 전체 삭제되어야함
            deleteTheater(theaterId);
        }
        // screenInfo로 넘어가서 처리
        else if (choice == 3) {
            printScreenInfo(theaterId); // 현재 상영하고 있는 상영정보 보여줌

            screenInfoViewer.setT(t);
            screenInfoViewer.setLogIn(logIn);
            screenInfoViewer.showScreenInfo();
        } else {
            System.out.println(">>>상영관 목록으로 돌아갑니다.\n");
        }
    }

    private void updateTheater(int id) {
        TheaterDTO t = theaterController.selectOne(id);
        int choice = ScannerUtil.printint(sc, "수정할 항목 1. 이름 2. 위치 3. 전화번호 4. 전체 (0. 뒤로가기)>", 0, 4);
        if (choice != 0) {
            if (choice == 1) {
                t.setName(ScannerUtil.printString(sc, "수정할 이름: "));
            } else if (choice == 2) {
                t.setLocation(ScannerUtil.printString(sc, "수정할 위치: "));
            } else if (choice == 3) {
                String num = ScannerUtil.printString(sc, "수정할 상영관 연락처(10자리): ");
                while (num.length() != 10) {
                    num = ScannerUtil.printString(sc, "잘못된 연락처입니다. 10자리로 다시 입력해주세요>");
                }
                t.setCallNumber(num);
            } else if (choice == 4) {
                t.setName(ScannerUtil.printString(sc, "수정할 이름: "));
                t.setLocation(ScannerUtil.printString(sc, "수정할 위치: "));
                String num = ScannerUtil.printString(sc, "수정할 상영관 연락처(9자리): ");
                while (num.length() != 9) {
                    num = ScannerUtil.printString(sc, "잘못된 연락처입니다. 9자리로 다시 입력해주세요>");
                }
                t.setCallNumber(num);
            }

            theaterController.update(t);
            System.out.println(">>>>>>>>>>>>>>>>>>상영관 수정 완료\n");
        } else {
            System.out.println("상영관 목록으로 돌아갑니다.\n");

        }
        showTheater();
    }

    // 상영관 삭제 시, 전체 상영기록 삭제
    private void deleteTheater(int id) {
        String answer = ScannerUtil.printString(sc, "상영관 삭제 시, 해당 상영관의 상영시간표 전체가 함께 삭제됩니다. 삭제하시겠습니까? (Y/N)>");
        if (answer.equalsIgnoreCase("Y")) {
            ArrayList<ScreenInfoDTO> screenInfoList = screenInfoController.theaterList(id);
            theaterController.delete(id);
            if (screenInfoList != null) {
                for (ScreenInfoDTO s : screenInfoList) {
                    screenInfoController.delete(s.getId());
                }
                System.out.println(">>>상영관 및 상영기록 전체 삭제 완료\n");
            } else {
                System.out.println(">>>상영목록 없음, 상영관만 삭제 완료\n");
            }
        } else {
            System.out.println(">>>삭제 취소, 상영관 목록으로 돌아갑니다.\n");

        }
        showTheater();
    }
}