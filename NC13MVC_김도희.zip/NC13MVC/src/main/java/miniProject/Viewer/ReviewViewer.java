package miniProject.Viewer;

import miniProject.ScannerUtil;
import lombok.Setter;
import miniProject.Controller.ReviewController;
import miniProject.Controller.MovieController;
import miniProject.Controller.UserController;
import miniProject.Model.ReviewDTO;
import miniProject.Model.MovieDTO;
import miniProject.Model.UserDTO;

import java.util.ArrayList;
import java.util.Objects;
import java.util.Scanner;
@Setter
public class ReviewViewer {
    private ReviewController reviewController;
    private MovieController movieController;
    private UserController userController;
    private MovieViewer movieViewer;
    private Scanner sc;
    private UserDTO logIn;
    private UserDTO u;
    private int choice;

    // 파라미터로 전달된 영화의 평점을 작성/출력하기 위해 choice에 따라서 분기점 만들기
    public void showGrade(MovieDTO m) {
            if (choice == 1) { // 평점 작성
                write(m.getId());
            } else if (choice == 2) { // 평점 출력
                printList(m.getId());
            }
    }

    // 평점 작성
    private void write(int movieId) {
        ReviewDTO r = new ReviewDTO();
        // 작성자 관련
        r.setWriterId(logIn.getId()); // id를 저장해두면 나중에 출력할 때 편함
        r.setRank(logIn.getRank()); // 일반 작성자인지, 평론가인지 구분하기 위해 rank를 가져와서 넣어줌
        // 영화 관련
        r.setMovieId(movieId);
        if (logIn.getRank() == 2) { // 평론가일때만 평론 작성
            r.setReview(ScannerUtil.printString(sc, "평가를 작성해주세요>"));
        }
        r.setGrade(ScannerUtil.printint(sc, "평점을 입력해주세요 (0~5점)>", 0, 5));

        reviewController.insert(r);

        // 작성 한번 끝날때마다 평점 업데이트
        MovieDTO m = movieController.selectOne(movieId);
        m.setGrade(reviewController.avg(Objects.requireNonNull(reviewController.movieReviewByRank(movieId, 3))));
        movieController.update(m);

        System.out.println(">>>평가 작성 완료\n영화 상세보기로 돌아갑니다.\n");
    }

    // 평점 출력
    private void printList(int movieId) {
        while (true) {
            int choice = ScannerUtil.printInt(sc, "1. 일반 관람객 평점보기 2. 평론가 평점보기 3. 전체 평점보기 (0. 뒤로가기)>", 0, 3);
            if (choice != 0) {
                printReview(movieId, choice);
            } else {
                System.out.println("영화 상세보기로 돌아갑니다.\n");
                break;
            }
        }
    }

    private void printReview(int movieId, int rank) {
        MovieDTO m = movieController.selectOne(movieId);
        ArrayList<ReviewDTO> list = reviewController.movieReviewByRank(movieId, rank);
        String name = "a";
        if (rank == 1) name = "일반 관람객";
        else if (rank == 2) name = "평론가";
        else if (rank == 3) name = "전체";

        if (list == null) {
            System.out.println("========================================");
            System.out.println("영화 '" + m.getTitle() + "' " + name + " 리뷰가 없습니다.");
            System.out.println("========================================\n");
        } else {
            // 일반 관객은 평론 적을수 없음, 평점만 가능
            System.out.println("========================================");
            if (reviewController.avg(list) == -1) {
                System.out.printf("영화 %s %s 평점: 0.00\n", m.getTitle(), name);
                System.out.println("----------------------------------------");
                System.out.println("아직 입력된 평가가 없습니다.");
            } else {
                System.out.printf("영화 %s %s 평점: %04.2f\n", m.getTitle(), name, reviewController.avg(list));
                System.out.println("----------------------------------------");
                for (ReviewDTO r : list) {
                    if (rank == 1 && r.getRank() == 1) { // 일반회원들 작성한거 프린트 writerId 가져와서 그 아이디로 userDTO랑 대비시켜 rank 가져옴
                        System.out.printf("%d. %s (%04.2f점)\n", r.getId(), userController.selectNicknameById(r.getWriterId()), r.getGrade());

                    } else if (rank == 2 && r.getRank() == 2) {
                        System.out.printf("%d. %s (%04.2f점): %s\n", r.getId(), userController.selectNicknameById(r.getWriterId()), r.getGrade(), r.getReview());

                    } else {
                        if (r.getRank() == 1) {
                            System.out.printf("%d. %s (%04.2f점)\n", r.getId(), userController.selectNicknameById(r.getWriterId()), r.getGrade());
                        } else {
                            System.out.printf("$d. %s (%04.2f점): %s\n", r.getId(), userController.selectNicknameById(r.getWriterId()), r.getGrade(), r.getReview());
                        }
                    }
                }
            }
            System.out.println("========================================\n");
        }
    }
}
