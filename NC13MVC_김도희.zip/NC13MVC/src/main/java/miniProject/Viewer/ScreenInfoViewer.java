package miniProject.Viewer;

import miniProject.ScannerUtil;
import lombok.Setter;
import miniProject.Controller.MovieController;
import miniProject.Controller.ScreenInfoController;
import miniProject.Model.MovieDTO;
import miniProject.Model.ScreenInfoDTO;
import miniProject.Model.TheaterDTO;
import miniProject.Model.UserDTO;

import java.util.ArrayList;
import java.util.Scanner;

@Setter
public class ScreenInfoViewer {
    private MovieViewer movieViewer;
    private TheaterViewer theaterViewer;
    private MovieController movieController;
    private ScreenInfoController screenInfoController;
    private UserDTO logIn;
    private TheaterDTO t;
    private Scanner sc;

    public void showScreenInfo() {
        ArrayList<MovieDTO> movieList = movieController.selectAll();
        while (logIn != null) {
            // 영화 리스트 비어있으면 등록할 수 잇는 영화 없음을 띄우고 있다면 영화 골라서 등록하게함
            if (movieList.isEmpty()) {
                System.out.println(">>>등록된 영화 없음");
                System.out.println(">>>상영관 목록으로 돌아갑니다\n");
                break;
            } else {
                if (logIn.getRank() == 5) {
                    int choice = ScannerUtil.printint(sc, "1. 새로운 상영 등록 2. 기존 상영 수정 3. 기존 상영 삭제 (0. 뒤로가기)>", 0, 3);
                    System.out.println();

                    if (choice == 1) {
                        insertScreenInfo();
                    } else if (choice == 2) {
                        updateScreenInfo();
                    } else if (choice == 3) {
                        deleteScreenInfo();
                    } else if (choice == 0) {
                        System.out.println(">>>상영관 상세보기로 돌아갑니다\n");
                        break;
                    }
                }
                // 일반 회원이라면 예매로 넘어감
                else {
                    selectScreenInfo();
                    break;
                }
            }
        }
    }

    private void selectScreenInfo() {
        int choice = ScannerUtil.printInt(sc, "상세보기할 상영정보 (0. 뒤로 가기)>");
        ArrayList<ScreenInfoDTO> screenList = screenInfoController.theaterList(t.getId());
        System.out.println();

        while (!screenInfoController.validateInput(choice)) {
            choice = ScannerUtil.printInt(sc, "존재하지 않음, 상세보기할 상영정보 (0. 뒤로 가기)>");
        }
        if (choice != 0) {
        } else {
            System.out.println(">>>상영 목록으로 돌아갑니다.\n");
        }
    }

    private void insertScreenInfo() {
        ArrayList<MovieDTO> movieList = movieController.selectAll();
        // 상영가능한 전체 영화 목록 보여주기
        System.out.println("=================================");
        System.out.println("        상영가능 영화 목록");
        for (MovieDTO m : movieList) {
            System.out.println("---------------------------------");
            System.out.printf("%d. %s\n", m.getId(), m.getTitle());
        }
        System.out.println("=================================");

        // 영화 번호 입력받아 넣어주기
        int movieId = ScannerUtil.printInt(sc, "등록할 영화 번호 입력 (0. 뒤로가기)>");
        while (!movieController.validateInput(movieId)) {
            movieId = ScannerUtil.printInt(sc, "잘못된 번호, 등록할 영화 번호 입력 (0. 뒤로가기)>");
        }
        if (movieId != 0) {
            ScreenInfoDTO s = new ScreenInfoDTO();
            MovieDTO m = movieController.selectOne(movieId);
            s.setMovieId(movieId);
            s.setTheaterId(t.getId());
            s.setTime(ScannerUtil.printInt(sc, "상영시간 (0시 ~ 23시)>", 0, 23));
            screenInfoController.insert(s);

            System.out.println(">>>상영시간표 등록완료\n");
        } else {
            System.out.println(t.getName() + " 상영정보 목록으로 돌아갑니다.\n");
        }
    }

    private void updateScreenInfo() { // 기존 상영영화 수정
        ArrayList<MovieDTO> movieList = movieController.selectAll();
        ArrayList<ScreenInfoDTO> screenInfoList = screenInfoController.theaterList(t.getId());

        if (screenInfoList != null) {
            System.out.println("============================================");
            System.out.println(t.getName() + "에서 현재 상영 중인 영화 목록");
            for (ScreenInfoDTO s : screenInfoList) {
                MovieDTO m = movieController.selectOne(s.getMovieId());
                System.out.println("--------------------------------------------");
                System.out.println(s.getId() + ". " + m.getTitle() + "\t||  상영 시간: " + s.getTime() + "시");
            }
            System.out.println("============================================");

            // 상영추가할 영화 번호 위에서 입력받아
            int screenId = ScannerUtil.printInt(sc, "수정할 상영번호 입력 (0. 뒤로가기)>");
            System.out.println();

            if (screenId == 0) {
                System.out.println(">>>상영정보 목록으로 돌아갑니다.\n");
            } else {
                if (!screenInfoController.validateInput(screenId)) {
                    System.out.println("존재하지 않는 정보입니다.\n");
                }
                // 존재하는 영화라면 상영정보 추가
                else {
                    if (movieList != null) {
                        System.out.println("=======================");
                        System.out.println("변경 가능한 영화 목록 출력");
                        for (MovieDTO m : movieList) {
                            System.out.println("-----------------------");
                            System.out.println(m.getId() + ". " + m.getTitle());
                        }
                        System.out.println("=======================");
                        ScreenInfoDTO s = screenInfoController.selectOne(screenId);
                        int movieId = ScannerUtil.printInt(sc, "변경하고 싶은 영화 번호>");
                        s.setMovieId(movieId);
                        s.setTime(ScannerUtil.printInt(sc, "상영시간 (0시 ~ 23시)>", 0, 23));
                        screenInfoController.update(s);

                        System.out.println(">>>상영시간표 수정완료\n");
                    } else {
                        System.out.println("\">>>등록된 영화가 없습니다.\n");
                    }
                }
            }
        } else { // list=null이라면
            System.out.println(">>>" + t.getName() + "에서 현재 상영중인 영화가 없습니다\n");
        }
    }

    private void deleteScreenInfo() {
        ArrayList<ScreenInfoDTO> screenInfoList = screenInfoController.theaterList(t.getId());

        if (screenInfoList != null) {
            System.out.println("============================================");
            System.out.println(t.getName() + "에서 현재 상영 중인 영화 목록 출력");
            for (ScreenInfoDTO s : screenInfoList) {
                MovieDTO m = movieController.selectOne(s.getMovieId());
                System.out.println("--------------------------------------------");
                System.out.println(s.getId() + ". " + m.getTitle() + "||  상영 시간: " + s.getTime() + "시");
            }
            System.out.println("============================================");

            // 상영추가할 영화 번호 위에서 입력받아
            int screenId = ScannerUtil.printInt(sc, "삭제할 상영번호 입력 (0. 뒤로가기)>");
            if (screenId == 0) {
                System.out.println(">>>상영정보 목록으로 돌아갑니다.\n");
            } else {
                if (!screenInfoController.validateInput(screenId)) {
                    System.out.println("존재하지 않는 정보입니다.\n");
                }
                // 존재하는 영화라면 상영정보 추가
                else {
                    String answer = ScannerUtil.printString(sc, "해당 상영정보를 삭제하시겠습니까? (Y/N)>");
                    if (answer.equalsIgnoreCase("Y")) {
                        screenInfoController.delete(screenId);
                        System.out.println(">>>상영시간표 삭제완료\n");
                    } else {
                        System.out.println(">>>삭제 취소, 상영정보 목록으로 돌아갑니다.\n");
                    }
                }
            }
        } else { // list=null이라면
            System.out.println(">>>" + t.getName() + "에서 상영중인 영화가 없습니다\n");
        }
    }
}
