package miniProject.Viewer;

import miniProject.ScannerUtil;
import lombok.Setter;
import miniProject.Controller.*;
import miniProject.Model.MovieDTO;
import miniProject.Model.ScreenInfoDTO;
import miniProject.Model.TheaterDTO;
import miniProject.Model.UserDTO;

import java.util.ArrayList;
import java.util.Scanner;

@Setter
public class MovieViewer {
    private UserViewer userViewer;
    private MovieController movieController;
    private ReviewViewer reviewViewer;
    private TheaterController theaterController;
    private ScreenInfoController screenInfoController;
    private Scanner sc;
    private UserDTO logIn; // 로그인 정보 전달받기 위함

    public void showMovie() {
        while (logIn != null) {
            ArrayList<MovieDTO> movielist = movieController.selectAll();
            if (logIn.getRank() == 5) {
                System.out.println("<관리자 모드>");
            } else {
                System.out.println("<일반 모드>");
            }

            if (movielist.isEmpty()) { // 등록된 영화 없을 경우
                System.out.println(">>>아직 등록된 영화가 없습니다.");

                if (logIn.getRank() == 5) { // 관리자라면 등록화면 띄우기
                    String answer = ScannerUtil.printString(sc, "영화를 등록하시겠습니까? (Y/N)>");
                    if (answer.equalsIgnoreCase("Y")) {
                        insertMovie();
                    } else {
                        System.out.println(">>>영화 및 상영관 관리 화면으로 돌아갑니다.\n");
                        userViewer.select();
                        break;
                    }
                } else { // 일반 회원이라면 다시 선택지로
                    System.out.println(">>>영화 및 상영관 화면으로 돌아갑니다.\n");
                    userViewer.select();
                    break;
                }
            }
            // 영화가 존재한다면
            else {
                System.out.println("=======================");
                System.out.println("   전체 영화 목록 출력");
                for (MovieDTO m : movielist) {
                    System.out.println("-----------------------");
                    System.out.printf("%d. %s\n", m.getId(), m.getTitle());
                }
                System.out.println("=======================");

                if (logIn.getRank() == 5) { // 관리자라면
                    int select = ScannerUtil.printint(sc, "1. 새로운 영화 추가 2. 기존 영화 상세보기 (0. 뒤로가기)>", 0, 2);
                    System.out.println();
                    if (select == 1) { // 새로운 영화출력
                        insertMovie();
                    } else if (select == 2) { // 기존 영화 수정
                        int choice = ScannerUtil.printInt(sc, "상세보기할 영화 번호 입력 (0. 뒤로가기)>");
                        System.out.println();
                        while (!movieController.validateInput(choice)) {
                            choice = ScannerUtil.printInt(sc, "존재하지 않는 영화, 재입력>");
                        }
                        if (choice != 0) {
                            printMovie(choice);
                        } else { // 뒤로가기
                            System.out.println(">>>영화 관리 화면으로 돌아갑니다.\n");
                        }
                    } else { // 뒤로가기
                        System.out.println(">>>영화 및 상영관 관리 화면으로 돌아갑니다.\n");
                        break;
                    }
                } else { // 일반 회원이라면
                    int choice = ScannerUtil.printInt(sc, "상세보기할 영화 번호 입력 (0. 뒤로가기)>");
                    System.out.println();
                    while (!movieController.validateInput(choice)) {
                        choice = ScannerUtil.printInt(sc, "존재하지 않는 영화, 재입력>");
                    }
                    if (choice != 0) {
                        printMovie(choice);
                    } else { // 뒤로가기
                        System.out.println(">>>영화 및 상영관 목록으로 돌아갑니다.\n");
                        break;
                    }
                }

            }
        }
    }

    // 영화 상세보기 출력, 스크린인포까지 하고 나면 상영시간까지 출력할것!!!!!!!!!!!!!!!!!!!!!
    private void printMovie(int choice) {
        while (true) {
            MovieDTO m = movieController.selectOne(choice); // 선택한 영화 객체 프린트
            System.out.println("====================================================");
            System.out.println(m.getId() + ".  " + m.getTitle() + "  평점: " + m.getGrade());
            System.out.println("----------------------------------------------------");
            System.out.println("줄거리: " + m.getSummary());
            System.out.println("====================================================");

            if (logIn.getRank() == 5) {
                controlMovie(m);
            } else {
                int select = ScannerUtil.printInt(sc, "1. 평점 작성하기 2. 평점 보기 (0. 뒤로가기)>", 0, 2);
                System.out.println();
                if (select == 0) {
                    System.out.println("전체 영화 목록을 출력합니다.");
                    break;
                } else {
                    writeReview(m, select);
                }
            }
        }
    }

    public void writeReview(MovieDTO m, int choice) { // 일반회원이라면 평가 작성하도록 함
        reviewViewer.setChoice(choice);
        reviewViewer.setLogIn(logIn);
        reviewViewer.showGrade(m);
    }


// 관리자일 경우 실행되는 메소드-------------------------------------------------------

    // 영화 추가
    private void insertMovie() {
        MovieDTO m = new MovieDTO();
        m.setTitle(ScannerUtil.printString(sc, "등록할 영화 제목: "));
        m.setSummary(ScannerUtil.printString(sc, "등록할 영화 줄거리: "));
        // 평점은 아직 등록되지 않았기 때문에 세팅하지 x

        movieController.insert(m);
        System.out.println(">>>영화 등록 완료\n");
    }

    // 기존 영화 수정 및 삭제
    private void controlMovie(MovieDTO m) {
        int choice = ScannerUtil.printint(sc, "1. 영화 수정 2. 영화 삭제 3. 상영관 지정 (0. 뒤로가기)>", 0, 3);
        System.out.println();

        if (choice == 1) {
            updateMovie(m.getId());
        } else if (choice == 2) { // 관리자가 영화를 삭제하게 되면 리뷰도 전체 삭제되어야함
            deleteMovie(m.getId());
        } else if (choice == 3) {
            selectTheater(m.getId());
        } else {
            System.out.println(">>>영화 목록으로 돌아갑니다.\n");
        }
    }

    private void updateMovie(int id) {
        MovieDTO m = movieController.selectOne(id);
        int choice = ScannerUtil.printint(sc, "수정할 항목 1. 제목 2. 줄거리 3. 전체 (0. 뒤로가기)>", 0, 3);
        if (choice != 0) {
            if (choice == 1) {
                m.setTitle(ScannerUtil.printString(sc, "수정할 제목: "));
            } else if (choice == 2) {
                m.setSummary(ScannerUtil.printString(sc, "수정할 줄거리: "));
            } else if (choice == 3) {
                m.setTitle(ScannerUtil.printString(sc, "수정할 제목: "));
                m.setSummary(ScannerUtil.printString(sc, "수정할 줄거리: "));
            }

            movieController.update(m);
            System.out.println(">>>영화 수정 완료\n");
        } else {
            System.out.println(">>영화 목록으로 돌아갑니다.");
        }
    }

    private void deleteMovie(int id) {
        String answer = ScannerUtil.printString(sc, "영화 삭제 시, 해당 영화의 상영시간표 전체가 함께 삭제됩니다. 삭제하시겠습니까? (Y/N)>");
        if (answer.equalsIgnoreCase("Y")) {
            movieController.delete(id);
            ArrayList<ScreenInfoDTO> screenInfoList = screenInfoController.movieList(id); // 해당 영화가 상영되는 시간표 전제 갖고와서
            if (screenInfoList != null) { // 만약 상영되고 있는게 있다면
                for (ScreenInfoDTO s : screenInfoList) {
                    screenInfoController.delete(s.getId());
                }
                System.out.println(">>>영화 및 해당 상영시간표 전체 삭제 완료\n");
            } else { // 상영되는게 없다면
                System.out.println(">>>상영정보 존재하지 않음, 영화만 삭제 완료\n");
            }
        } else {
            System.out.println(">>>영화 목록으로 돌아갑니다.\n");
        }
    }

    // 파라미터로 전달된 영화id
    private void selectTheater(int id) { // 상영관 지정하면 screenInfo를 불러내서 입력하게됨
        // 상영가능한 전체 리스트 목록 출력
        ArrayList<TheaterDTO> list = theaterController.selectAll();
        System.out.println("=======================");
        System.out.println("   전체 상영관 목록 출력");
        if (list.isEmpty()) {
            System.out.println("-----------------------");
            System.out.println("아직 등록된 상영관 X");
            System.out.println("=======================");
            System.out.println(">>>영화 목록으로 돌아갑니다.\n");
        } else {
            for (TheaterDTO t : list) {
                System.out.println("-----------------------");
                System.out.printf("%d. %s\n", t.getId(), t.getName());
            }
            System.out.println("=======================");

            // 이미 해당 영화가 상영되고 있는 상영시간표가 있다면
            MovieDTO m = movieController.selectOne(id);
            ArrayList<ScreenInfoDTO> screenList = screenInfoController.movieList(id); // 상영관 영화 시간표 list
            System.out.println("========================================");
            System.out.println("선택하신 '" + m.getTitle() + "' 상영중인 상영관 목록");
            if (screenList != null) {
                for (ScreenInfoDTO s : screenList) { // 선택한 상영관에서 상영중인 영화에서 이름,
                    // 상영관에서 movieId가 같은 애의 영화관 아이디를 가져와서 아래에 넣기
                    TheaterDTO t = theaterController.selectOne(s.getTheaterId());
                    System.out.println("----------------------------------------");
                    System.out.println(s.getId() + ". 상영관: " + t.getName() + " 상영시간: " + s.getTime());
                }
                System.out.println("========================================");
                System.out.println();
            }
            // 상영중인 영화가 없다면
            else {
                System.out.println("----------------------------------------");
                System.out.println("아직 상영 x");
                System.out.println("========================================");
                System.out.println();
            }
            // 상영을 희망하는 상영관 고르게함
            int theaterId = ScannerUtil.printInt(sc, "상영하고싶은 상영관 번호 (0. 뒤로가기)>");

            if (!theaterController.validateInput(theaterId)) {
                System.out.println("존재하지 않는 상영관입니다.\n");
            } else if (theaterId != 0) {
                int time = ScannerUtil.printInt(sc, "상영시간 (0시 ~ 23시)>", 0, 23);
                ScreenInfoDTO s = new ScreenInfoDTO();
                TheaterDTO t = theaterController.selectOne(theaterId);
                s.setMovieId(id);
                s.setTime(time);
                s.setTheaterId(theaterId);
                screenInfoController.insert(s);

                System.out.println(">>>" + s.getId() + ". 영화이름: " + m.getTitle() + " 상영장소: " + t.getName() + " 상영시간: " + s.getTime());
                System.out.println(">>>상영관 지정 완료\n");
            } else {
                System.out.println(">>>영화 목록으로 돌아갑니다.\n");
            }
        }
    }
}