package miniProject.Viewer;

import miniProject.ScannerUtil;
import lombok.Setter;
import miniProject.Controller.MovieController;
import miniProject.Controller.UserController;
import miniProject.Model.UserDTO;

import java.util.ArrayList;
import java.util.Scanner;

public class UserViewer {
    @Setter
    private UserController userController;
    @Setter
    private MovieController movieController;
    @Setter
    private Scanner sc;
    @Setter
    private UserDTO logIn; // 로그인 유지위함
    @Setter
    private MovieViewer movieViewer;
    @Setter
    private TheaterViewer theaterViewer;

    public void showIndex() {
        while (true) {
            int choice = ScannerUtil.printInt(sc, "1. 로그인 2. 회원가입 3. 종료 >", 1, 3);
            if (choice == 1) {
                auth(); // 로그인
                if (logIn != null) { // 로그인 성공시
                    select();
                }
            } else if (choice == 2) {
                register(); // 회원가입
            } else if (choice == 3) {
                System.out.println("사용해주셔서 감사합니다.");
                break;
            }
        }
    }

    public void select() {
        while (logIn != null) {
            if (logIn.getRank() == 5) {
                System.out.println("<관리자 모드>");
                int select = ScannerUtil.printint(sc, "1. 회원 관리 2. 영화 3. 상영관 (0. 뒤로가기)>", 0, 3);
                System.out.println();
                if (select == 1) {
                    controlUser();
                } else if (select == 2) { // 영화
                    // 보여질 메인, rank에 따라서 보여지는 옵션이 달라야함
                    movieViewer.setLogIn(logIn); // 로그인 정보 전달
                    movieViewer.showMovie();
                } else if (select == 3) { // 상영관
                    theaterViewer.setLogIn(logIn);
                    theaterViewer.showTheater();
                } else {
                    System.out.println(">>>관리자 권한 초기화면으로 돌아갑니다.");
                    String exit = ScannerUtil.printString(sc, "! 관리자 권한 종료하시겠습니까? (Y/N)>");
                    if (userController.logOut(exit, logIn) == null) {
                        logIn = null;
                        System.out.println(">>>관리자 로그아웃합니다.\n");
                        break;
                    } else {
                        System.out.println(">>>관리자 모드로 다시 돌아갑니다.\n");
                    }
                }
            } else {
                System.out.println("<일반 모드>");
                int select = ScannerUtil.printint(sc, "1. 영화 2. 상영관 (0. 뒤로가기)>", 0, 2);
                System.out.println();
                if (select == 1) { // 영화
                    // 보여질 메인, rank에 따라서 보여지는 옵션이 달라야함
                    movieViewer.setLogIn(logIn); // 로그인 정보 전달
                    movieViewer.showMovie();
                } else if (select == 2) { // 상영관
                    theaterViewer.setLogIn(logIn);
                    theaterViewer.showTheater();
                } else { // 뒤로가기
                    String exit = ScannerUtil.printString(sc, "! 로그아웃하시겠습니까? (Y/N)>");
                    if (userController.logOut(exit, logIn) == null) {
                        logIn = null;
                        System.out.println(">>>로그아웃합니다.\n");
                        break;
                    } else {
                        System.out.println(">>>영화 및 상영관 선택으로 돌아갑니다.\n");
                    }
                }
            }

        }
    }

    // 로그인
    private void auth() {
        String username = ScannerUtil.printString(sc, "아이디> ");
        String password = ScannerUtil.printString(sc, "비번> ");

        logIn = userController.auth(username, password);

        if (logIn == null) System.out.println("잘못입력, 로그인 정보 재확인");
        else System.out.println(">>>로그인 성공\n");
    }

    // 회원가입
    private void register() {
        String username = ScannerUtil.printString(sc, "사용할 아이디>");
        while (!userController.validateUsername(username)) {
            System.out.println("중복된 아이디, 재입력하세요");
            username = ScannerUtil.printString(sc, "사용할 아이디>");
        }
        String password = ScannerUtil.printString(sc, "사용할 비번>");
        String nickname = ScannerUtil.printString(sc, "사용할 닉네임>");

        UserDTO u = new UserDTO();
        u.setUsername(username);
        u.setPassword(password);
        u.setNickname(nickname);

        userController.insert(u);
        System.out.println(">>>회원가입 완료\n");
    }

    // 관리자 권한---------------------------------------------------------------------------------
    private void controlUser() {
        while (logIn.getRank() == 5) {
            System.out.println("==================================");
            System.out.println("! 회원 관리 !");
            ArrayList<UserDTO> list = userController.selectAll();
            System.out.println("----------------------------------\n번호  이름  등급");
            for (UserDTO u : list) {
                if (u.getRank() == 1) {
                    System.out.printf(" %d.   %s    일반\n", u.getId(), u.getUsername());
                } else if (u.getRank() == 2) {
                    System.out.printf(" %d.   %s   평론가\n", u.getId(), u.getUsername());
                } else {
                    System.out.printf(" %d.   %s   관리자\n", u.getId(), u.getUsername());
                }
            }
            System.out.println("==================================");

            String choice = ScannerUtil.printString(sc, "! 회원 Rank 수정하시겠습니까? (Y/N)>");
            if (choice.equalsIgnoreCase("Y")) {
                changeRank();
            } else {
                System.out.println(">>>영화 및 상영관 관리 화면으로 돌아갑니다.\n");
                break;
            }
        }
    }

    // 관리자 회원 등급 변경
    private void changeRank() {
        int choice = ScannerUtil.printInt(sc, "! 수정할 회원의 번호를 입력 (0. 뒤로가기)>");
        while (!userController.validateInput(choice)) { // 회원 id가 없을경우, 존재하지 않는 회원
            choice = ScannerUtil.printInt(sc, ">>>없는 회원입니다.\n! 수정할 회원의 번호를 입력 (0. 뒤로가기)>");
        }

        // 회원이 존재할 경우
        if (choice != 0) {
            UserDTO u = userController.selectOne(choice);
            int rank = ScannerUtil.printInt(sc, "! 변경할 등급 (1. 일반 2. 평론가 3. 관리자)>", 1, 3);
            if (rank == 3) { // 관리자 지정
                u.setRank(5);
            } else {
                u.setRank(rank);
            }
            System.out.println(">>>" + u.getId() + "번 회원 등급 변경 완료\n");
        } else {
            System.out.println(">>>관리자 권한 화면으로 돌아갑니다.\n");
        }
    }
}
