package miniProject.main;

import miniProject.Controller.*;
import miniProject.Viewer.*;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // 각종 컨트롤러
        UserController userController = new UserController();
        MovieController movieController = new MovieController();
        ReviewController reviewController = new ReviewController();
        TheaterController theaterController = new TheaterController();
        ScreenInfoController screenInfoController = new ScreenInfoController();

        // 각종 뷰어
        UserViewer userViewer = new UserViewer();
        MovieViewer movieViewer = new MovieViewer();
        ReviewViewer reviewViewer = new ReviewViewer();
        TheaterViewer theaterViewer = new TheaterViewer();
        ScreenInfoViewer screenInfoViewer = new ScreenInfoViewer();

        // Setter 사용한 의존성 주입
        userViewer.setSc(sc);
        userViewer.setUserController(userController);
        userViewer.setMovieController(movieController);
        userViewer.setMovieViewer(movieViewer);
        userViewer.setTheaterViewer(theaterViewer);
//        userViewer.setScreenInfoViewer(screenInfoViewer);

        movieViewer.setSc(sc);
        movieViewer.setUserViewer(userViewer);
        movieViewer.setMovieController(movieController);
        movieViewer.setReviewViewer(reviewViewer);
        movieViewer.setTheaterController(theaterController);
        movieViewer.setScreenInfoController(screenInfoController);

        reviewViewer.setSc(sc);
        reviewViewer.setUserController(userController);
        reviewViewer.setMovieController(movieController);
        reviewViewer.setMovieViewer(movieViewer);
        reviewViewer.setReviewController(reviewController);

        theaterViewer.setSc(sc);
        theaterViewer.setTheaterController(theaterController);
        theaterViewer.setMovieViewer(movieViewer);
        theaterViewer.setMovieController(movieController);
        theaterViewer.setUserViewer(userViewer);
        theaterViewer.setScreenInfoViewer(screenInfoViewer);
        theaterViewer.setScreenInfoController(screenInfoController);

        screenInfoViewer.setSc(sc);
        screenInfoViewer.setMovieViewer(movieViewer);
        screenInfoViewer.setTheaterViewer(theaterViewer);
        screenInfoViewer.setMovieController(movieController);
        screenInfoViewer.setScreenInfoController(screenInfoController);

        userViewer.showIndex();
    }
}
